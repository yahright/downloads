# SCOPY Benchmark Kit

A self-contained, portable kit for measuring SCOPY copy throughput against
FastCopy and Robocopy on **any Windows x64 machine**. No installation, no .NET
runtime required — `scopy.exe` is a native static binary.

## Contents

| File | Purpose |
| --- | --- |
| `scopy.exe` | SCOPY CLI (x64). Includes the `gen` dataset generator and `copy`. |
| `run-bench.ps1` | Benchmark runner: generates datasets, runs the tools, reports medians. |
| `README.md` | This file. |

## Quick start

```powershell
# From the kit folder. DataRoot = where datasets are generated (source disk),
# DestRoot = copy target (the disk/path you want to benchmark).
pwsh ./run-bench.ps1 -DataRoot C:\scopy-bench\src -DestRoot D:\scopy-bench\dst
```

This generates the four canonical datasets, copies each with SCOPY and Robocopy
(plus FastCopy if you point to it), discards a warmup run, and prints the median
throughput over 7 runs, plus a `bench-<timestamp>.csv` with raw samples.

### Include FastCopy in the comparison

```powershell
pwsh ./run-bench.ps1 -DataRoot C:\b\src -DestRoot D:\b\dst `
    -FastCopyExe "C:\Program Files\FastCopy\FastCopy.exe"
```

FastCopy is **not redistributed** in this kit. Download it separately from the
official site and pass its path.

### Pick datasets / sizes

```powershell
# Only the large-file battleground, at 16 GiB, fewer repeats:
pwsh ./run-bench.ps1 -DataRoot C:\b\src -DestRoot D:\b\dst `
    -Presets large-single -LargeSize 16GiB -Repeat 5
```

## Datasets (canonical use cases)

| Preset | Shape | What it stresses |
| --- | --- | --- |
| `small-files` | 10000 x 4 KiB across 100 dirs | file-create latency, syscall count |
| `large-single` | 1 x 1 GiB (`-LargeSize` to change) | sequential throughput (FastCopy's strength) |
| `multi-large` | 4 x 1 GiB | cross-file scheduling, device contention |
| `mixed-tree` | ~600 files, mixed 2 KiB–48 MiB, nested | real-world folder copy |

Datasets are **reproducible**: the same `-Seed` and sizes always produce the
same bytes, so numbers from different machines are directly comparable.

## Generate datasets only

```powershell
.\scopy.exe gen C:\scopy-bench\src --preset all
.\scopy.exe gen C:\scopy-bench\src --preset small-files,mixed-tree --output json
.\scopy.exe gen --help
```

## Reporting results back

Send the generated `bench-*.csv` plus your machine details (CPU, RAM, source &
destination drive type — NVMe / SATA SSD / HDD / SMB). Wall-clock time is the
metric; it includes process startup, open, transfer, flush, and close.

## Notes

- Run with the **High performance** power plan for stable numbers.
- Source and destination should be on the intended drives — copying within one
  fast NVMe is a different test from NVMe→HDD or →SMB.
- `run-bench.ps1` resets the destination and waits for the delete to settle
  between runs so cleanup does not bleed into timing.
