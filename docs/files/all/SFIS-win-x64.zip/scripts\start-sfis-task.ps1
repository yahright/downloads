[CmdletBinding()]
param(
    [string]$TaskName = "SFIS"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Start-ScheduledTask -TaskName $TaskName
Write-Host "Started scheduled task '$TaskName'."
