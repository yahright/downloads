[CmdletBinding()]
param(
    [string]$TaskName = "SFIS"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Stop-ScheduledTask -TaskName $TaskName
Write-Host "Stopped scheduled task '$TaskName'."
