﻿# SFIS - SFileIndexService

High-speed file index service using NTFS MFT (Windows) and Spotlight (macOS).
Written in C++ with gRPC. C# client SDK included for InsightFlow / QuickNav.

## Structure

- proto/           Protobuf definitions (shared between C++ and C#)
- sfis/            C++ service (CMake)
- SFIS.Client/     C# client SDK (.NET 8)
- SFIS.sln         C# solution (client only)
- CMakeLists.txt   C++ root build file
- vcpkg.json       C++ dependencies

## Build C++ service

Requires vcpkg with grpc and protobuf installed.

    cmake -B build -DCMAKE_TOOLCHAIN_FILE=<vcpkg>/scripts/buildsystems/vcpkg.cmake
    cmake --build build --config Release

## Build C# client

    dotnet build SFIS.Client/SFIS.Client.csproj