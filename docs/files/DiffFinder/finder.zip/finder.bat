@echo off

REM ====== �ݒ� ======
set TARGET_CPP=foo.cpp
set TARGET_OBJ=foo.obj
set TARGET_EXE=app.exe
set TARGET_LIB=your_big.lib

set OBJ_DIR=.\Debug
set OUT_DIR=dump_check

REM ====== ���� ======
if not exist %OUT_DIR% mkdir %OUT_DIR%

echo =========================================
echo [1] showIncludes�t���r���h�i���O�擾�j
echo =========================================

REM �������͊��ɍ��킹��
REM nmake / build / devenv / msbuild �ȂǂɕύX
REM ��Fdevenv
REM devenv your.sln /build Debug > %OUT_DIR%\build.log

echo �������͎蓮�ł�OK�ishowIncludes ON�Ńr���h�j
pause

echo =========================================
echo [2] .obj �� .h �̃^�C���X�^���v�m�F
echo =========================================

echo ---- OBJ ----
dir /t:w %OBJ_DIR%\%TARGET_OBJ%

echo ---- CPP ----
dir /t:w %TARGET_CPP%

echo ---- LIB ----
dir /t:w %TARGET_LIB%

echo =========================================
echo [3] DUMPBIN (BEFORE)
echo =========================================

dumpbin /headers    %TARGET_EXE% > %OUT_DIR%\before.headers.txt
dumpbin /imports    %TARGET_EXE% > %OUT_DIR%\before.imports.txt
dumpbin /dependents %TARGET_EXE% > %OUT_DIR%\before.dependents.txt
dumpbin /exports    %TARGET_EXE% > %OUT_DIR%\before.exports.txt

dumpbin /linkermember %TARGET_LIB% > %OUT_DIR%\before.lib.txt
dumpbin /directives  %TARGET_LIB% > %OUT_DIR%\before.directives.txt

echo =========================================
echo [4] STOP: �����ŃR�[�h�ύX���ăr���h������
echo =========================================
pause

echo =========================================
echo [5] DUMPBIN (AFTER)
echo =========================================

dumpbin /headers    %TARGET_EXE% > %OUT_DIR%\after.headers.txt
dumpbin /imports    %TARGET_EXE% > %OUT_DIR%\after.imports.txt
dumpbin /dependents %TARGET_EXE% > %OUT_DIR%\after.dependents.txt
dumpbin /exports    %TARGET_EXE% > %OUT_DIR%\after.exports.txt

dumpbin /linkermember %TARGET_LIB% > %OUT_DIR%\after.lib.txt
dumpbin /directives  %TARGET_LIB% > %OUT_DIR%\after.directives.txt

echo =========================================
echo [6] �����`�F�b�N
echo =========================================

echo ---- IMPORTS ----
fc /n %OUT_DIR%\before.imports.txt %OUT_DIR%\after.imports.txt

echo ---- DEPENDENTS ----
fc /n %OUT_DIR%\before.dependents.txt %OUT_DIR%\after.dependents.txt

echo ---- EXPORTS ----
fc /n %OUT_DIR%\before.exports.txt %OUT_DIR%\after.exports.txt

echo ---- LIB MEMBERS ----
fc /n %OUT_DIR%\before.lib.txt %OUT_DIR%\after.lib.txt

echo =========================================
echo [7] OBJ�폜�e�X�g�i�C�Ӂj
echo =========================================
echo �폜���čăr���h����Ȃ�Y
set /p DELYN=Delete obj? (y/n): 

if /i "%DELYN%"=="y" (
    del %OBJ_DIR%\%TARGET_OBJ%
    echo OBJ deleted. �ăr���h���ċ����m�F����
)

echo =========================================
echo DONE
echo =========================================
pause