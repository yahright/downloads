# SFIS Architecture Notes

## Mount Scope

A mount is the root scope where a client explicitly requests indexing
responsibility. It is not just a backend implementation detail; it is the unit
used to reason about lifecycle, visibility, refresh, watch reliability, and
client policy.

Mount scope examples:

- Volume mount: `C:\`
- Folder mount: `C:\repo`
- Network mount: `\\server\share\project`
- Future cloud mount: provider/root pair
- Future macOS mount: `/Users/name/project`

`Search`, `ListFiles`, and `GetFolderSize` operate on indexed state inside
mount scopes. Refresh, polling, watch, policy, status, failures, and reactive
mount events are mount-level concepts. Files are indexed entities inside a
mount; they are not independent lifecycle or visibility owners.

## Mount Lifecycle

Mount creation is explicit. A client requests `MountIndex` with a root path,
backend hint, policy, and requester string. A mount can then be refreshed,
polled, watched, listed, and removed by mount id. The mount manager remains the
source of truth for active mount state; the refresh scheduler keeps only a
runtime cache of schedulable mount snapshots.

SFIS does not implicitly recursive-crawl all drives or folders. Recursive
indexing is allowed only when a client explicitly asks for a mount using an
appropriate backend/policy, and recurring refresh requires an explicit refresh
interval. `0` disables scheduled refresh for that mount.

## Reactive IPC Semantics

Reactive IPC is a live notification stream, not a durable event log. Clients
must treat events as hints and reconcile state after reconnect or errors. The
authoritative state is obtained by querying current state through APIs such as
`GetStatus`, `ListMounts`, `ListMountConfigs`, `Search`, and `ListFiles`.

Mount event envelopes carry a process-local monotonic `event_id`. The value is
not persisted, is reset on process restart, and cannot be used as a durable
cursor. Delivery is best-effort for the active pipe connection only. SFIS does
not guarantee replay, reconnect history, or delivery of events that occurred
while a client was disconnected.

Each subscribed pipe has a bounded pending event queue. If a subscriber falls
behind and the queue overflows, SFIS closes that pipe connection and implicitly
removes the subscription. Slow subscribers do not block other subscribers.
Clients should reconnect explicitly and then resync state before using future
events. SDKs do not automatically reconnect subscriptions.

`EventsLost` is reserved as a future event type for explicit loss notification,
but M6.3 does not emit it.

`MountInvalidated` is the first query/cache invalidation event. It is
mount-scoped and remains a hint, not truth. Clients should use it to invalidate
cached search results, folder listings, indexed mount state, or AI indexing
queues, then reconcile with `Search`, `ListFiles`, `GetStatus`, or
`ListMounts`. It is not a filesystem delta stream, does not include changed
file lists, and is not tracked per query.

Each `IndexMount` carries a process-local `generation` value. SFIS increments
the generation when indexed state is successfully replaced or changed, including
initial recursive mount scan completion, successful recursive refresh, and NTFS
USN watcher update batches. Failed refreshes and empty/failed watcher updates do
not increment generation. Watcher invalidations use `trigger = "Watch"`,
`reason = "usn update"`, and a coarse batch count as `changed_file_estimate`.
The generation is appended to mount IPC payloads and is included in
`MountInvalidated`; it is not persisted across restart and is not a replay
cursor.

## Access Control Model

SFIS does not guarantee per-file ACL-correct query results. Access control is
handled at mount scope, pipe access, and client policy boundaries. A caller that
can access a pipe and query a mount should be treated as authorized for that
mount by the embedding product or service policy.

This is deliberate:

- Storing NTFS ACL state for every file would enlarge the index and complicate
  updates.
- Query-time ACL filtering makes pagination, totals, and reactive updates hard
  to define predictably.
- Local, network, cloud, and virtual filesystems do not share one portable ACL
  model.
- SFIS is a filesystem indexing substrate, not a security boundary.

Products embedding SFIS should enforce user authorization before granting pipe
access, creating mounts, exposing mount ids, or showing query results.

## Security Non-Goals

SFIS does not currently implement:

- File ACL indexing
- Per-client authentication
- Per-client visibility filtering
- Security descriptor storage
- Query-time ACL filtering
- Persistent subscriptions
- Authenticated replay/history

The pipe security descriptor restricts who can connect to the service pipe, but
it does not transform SFIS into a per-file authorization layer.

## Future Multi-Client Considerations

The following terms are reserved for future design and should keep their
mount-scope meaning:

- `owner_context`: the authority or product context that owns a mount request.
- `visibility`: which clients or client groups may discover and query a mount.
- `security_model`: the policy model used by a host product to authorize mount
  access.
- `client_id`: a stable client identity used for audit, leases, or policy.
- Mount lease: a future lifetime/ownership mechanism for mounts created by
  clients.

These concepts are not implemented in M6.2. They exist to keep future
persistence, multi-client operation, and AI indexing integrations aligned with
the mount as the policy and lifecycle boundary.
