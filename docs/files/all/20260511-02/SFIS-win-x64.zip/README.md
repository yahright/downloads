﻿# SFIS - SFileIndexService

High-speed file index service using NTFS MFT (Windows) and Spotlight (macOS).
Written in C++ with gRPC. C# client SDK included for InsightFlow / QuickNav.

## Structure

- proto/           Protobuf definitions (shared between C++ and C#)
- sfis/            C++ service (CMake)
- SFIS.Client/     C# client SDK (.NET 8)
- SFIS.sln         C# solution (client only)
- CMakeLists.txt   C++ root build file
- vcpkg.json       C++ dependencies

## Build C++ service

Requires vcpkg with grpc and protobuf installed.

    cmake -B build -DCMAKE_TOOLCHAIN_FILE=<vcpkg>/scripts/buildsystems/vcpkg.cmake
    cmake --build build --config Release

On macOS:

    ./build-macos.sh Release

Or double-click `build-macos.command` in Finder.

To build the user-level macOS zip package:

    ./build-macos-zip.sh

The package installs `sfis` and `sfisctl` under
`~/Library/Application Support/SFIS/bin` and registers a per-user LaunchAgent
with `scripts/install-sfis-macos.sh`. It also includes SFIS Monitor under
`~/Library/Application Support/SFIS/SFIS.Monitor`; launch it from Terminal with
`scripts/run-sfis-monitor-macos.sh`. The macOS Monitor package is unsigned and
is not a `.app` bundle yet.

## Build C# client

    dotnet build SFIS.Client/SFIS.Client.csproj

## Architecture Summaries

- [Install layout and packaging plan](docs/install-layout.md)
- [M6/M7 stabilization summary](docs/milestone-m6-m7.md)
- [Architecture notes](docs/architecture.md)
- [Test notes](docs/test.md)

## Mount Scope

An SFIS mount is the root scope where a client explicitly requests indexing
responsibility. Examples include a volume mount such as `C:\`, a folder mount
such as `C:\repo`, a network mount such as `\\server\share\project`, a future
cloud provider/root pair, or a future macOS root such as
`/Users/name/project`.

`Search`, `ListFiles`, and `GetFolderSize` operate on indexed state inside
mount scopes. Refresh, polling, watch status, policy, lifecycle, and reactive
events are mount-scoped. The mount is the basic unit for visibility, policy, and
lifecycle decisions.

SFIS does not implicitly recursive-crawl every drive or folder. Recursive
indexing happens only through explicit `MountIndex` requests, with an explicit
backend/policy and optional refresh interval.

## Access Control Model

SFIS does not guarantee per-file ACL-correct query results. Access control is
enforced at mount scope, pipe access, and client policy boundaries. SFIS is a
filesystem indexing substrate, not a security enforcement layer.

File-level ACL indexing and query-time ACL filtering are non-goals because they
inflate the index, make pagination and total counts unstable, and do not map
consistently across local, network, cloud, and virtual filesystems.

Future multi-client terms reserved for design work include `owner_context`,
`visibility`, `security_model`, `client_id`, and mount lease. They are not
implemented yet.

## Binary IPC compatibility

Binary IPC remains protocol v2. New commands and packet types are append-only,
so existing commands and payload layouts are unchanged. Older clients can
continue using v2 but do not know newer commands.

Protocol version means wire-format compatibility only. Feature/API support is
advertised separately in the Hello response as append-only grouped capability
strings: commands, event types, then features. Clients should ignore capability
strings they do not understand and gate optional APIs by advertised support.

`SetMountRefreshInterval` is command `10`. Mount polling is opt-in: the server
schedules refreshes only for mounts whose interval was explicitly set by a
client; `0` disables scheduling for that mount.

Reactive IPC foundation is available through `Subscribe` command `11`,
`Unsubscribe` command `12`, and server-to-client `Event` packet type `7`.
Event packets use `request_id = 0` and currently carry whole-stream mount
events only: `MountCreated`, `MountStatusChanged`, `MountRefreshed`,
`MountRemoved`, `MountFailed`, and `MountInvalidated`. `EventsLost` is reserved
for a future loss notification event and is not emitted today.

Reactive IPC is a live notification stream, not a durable event log. Clients
must treat events as hints and reconcile state after reconnect or errors.
Truth is obtained by querying current state with `GetStatus`, `ListMounts`,
`ListMountConfigs`, `Search`, or `ListFiles`.

Event envelopes are ordered by the process-local monotonic `event_id` assigned
by `IndexMountManager`. `event_id` is not persisted and is reset when the
process restarts. Delivery is best-effort for the active pipe connection: there
is no persistence, replay, reconnect history, or guaranteed delivery after a
client reconnects. Each subscribed pipe has a bounded pending event queue; if a
subscriber falls behind and the queue overflows, the server drops that pipe
connection and the subscriber is implicitly removed. The exact queue size is an
implementation detail. Clients should reconnect explicitly and resync state;
the C# SDK does not automatically reconnect subscriptions.

`MountInvalidated` is a mount-scoped cache invalidation hint. It means indexed
state for the mount changed and clients should invalidate cached search
results, folder listings, mount status views, or indexing queues, then query
SFIS for current truth. It is not a file-level delta stream and does not carry
changed file lists. The payload includes the mount id from the event envelope,
a reason, a process-local mount `generation`, a `changed_file_estimate` value
currently set to `0`, and a trigger such as `MountLifecycle`, `ManualRefresh`,
`SchedulerRefresh`, or `Watch`. NTFS USN watcher updates are coalesced per read
batch and emit `MountInvalidated` with `reason = "usn update"`,
`trigger = "Watch"`, and the batch count as `changed_file_estimate`. Mount
generation is not persisted across restart.

Current advertised features include `reactive-ipc`,
`mount-refresh-scheduler`, `watch-reliability`, `recursive-backend`, and
`persistent-mount-config`, and `query-invalidation-events`.

## Client IPC Endpoints

The C# SDK keeps the same public client API across platforms and selects the
transport from the OS:

- Windows: named pipe `sfis`, overridden by `SFIS_PIPE_NAME`.
- macOS: Unix domain socket
  `~/Library/Application Support/SFIS/run/sfis.sock`, overridden by
  `SFIS_SOCKET_PATH`.
- Linux fallback: Unix domain socket `$HOME/.local/share/SFIS/sfis.sock`,
  overridden by `SFIS_SOCKET_PATH`.

`sfisctl` follows the same split. On Windows use `--pipe <name>` or
`SFIS_PIPE_NAME`; on macOS/Linux use `--socket-path <path>` or
`SFIS_SOCKET_PATH`.

## Service Logs

SFIS writes a plain text diagnostic log on startup. Log path priority is:
`--log-path <path>`, `SFIS_LOG_PATH`, `<sfis executable directory>/logs/sfis.log`,
then the platform fallback.

Installed Windows services use:

```text
C:\Program Files\SFIS\logs\sfis.log
```

If that path is not writable, SFIS falls back to:

```text
C:\ProgramData\SFIS\logs\sfis.log
```

Installed macOS LaunchAgents pass:

```text
~/Library/Application Support/SFIS/logs/sfis.log
```

Use `--log-level debug` for request-level IPC metadata. Startup logs include
the active log path, endpoint, index path, mount config path, pid, executable
path, and advertised protocol features. `sfisctl status` also reports
`log_path` and `log_level`.

Windows connection checklist:

```powershell
Get-Service SFIS
Get-Content "C:\Program Files\SFIS\logs\sfis.log" -Tail 100
Get-Content "C:\ProgramData\SFIS\logs\sfis.log" -Tail 100
.\sfisctl.exe status
```

macOS connection checklist:

```bash
launchctl print "gui/$UID/com.sfis.daemon"
tail -100 "$HOME/Library/Application Support/SFIS/logs/sfis.log"
sfisctl status
```

## Persistent Mount Restart Smoke Test

Windows-only restart behavior can be checked with:

    powershell -ExecutionPolicy Bypass -File scripts/test-persistent-mount.ps1

The script expects a built service executable at
`build\ARM64\Release\sfis.exe` by default and uses `SFIS.TestApp` through the
C# SDK. It starts `sfis.exe` with a unique pipe name and `--allow-multiple`,
creates a temporary recursive Persistent mount, sets a refresh interval, stops
and restarts the process, then verifies `status`, `list-mounts`, and
`mount-configs`.

The test is isolated from the real machine-wide config by setting
`SFIS_MOUNT_CONFIG_PATH` to a temporary `mounts.json`. `SFIS_INDEX_PATH` can
similarly override the default snapshot location. The default path resolver
lives in `sfis/include/platform_locations.h`: Windows uses `%ProgramData%\SFIS`
and macOS is guarded for `~/Library/Application Support/SFIS`.
Recursive filesystem metadata is isolated behind
`sfis/include/file_metadata.h` so the recursive backend can keep traversal
logic common while Windows and POSIX supply platform-specific attributes,
timestamps, and symlink/special-file handling.

## Reactive Event Smoke Test

Windows-only reactive IPC delivery can be checked with:

    powershell -ExecutionPolicy Bypass -File scripts/test-reactive-events.ps1

The script starts a real `sfis.exe` process with a unique pipe name, isolated
index path, and isolated mount config path, then runs
`SFIS.TestApp event-smoke <temp-root>` through the C# SDK. The smoke test
subscribes to mount events, creates a recursive Ephemeral mount, verifies mount
creation/status/invalidation events, refreshes the mount, verifies refresh
status/refreshed/invalidation events with a generation increment, unmounts, and
unsubscribes.

Reactive events are live hints, not a durable log. This smoke test verifies
delivery through the actual process, named pipe server, and SDK consumer for an
active subscription; it does not test replay, reconnect history, or durable
event storage.

## SFIS Monitor Dev Run

The Avalonia Monitor can be launched against an isolated real daemon with:

    powershell -ExecutionPolicy Bypass -File scripts/run-monitor-dev.ps1

The script starts `sfis.exe` with a unique pipe name, isolated index path, and
isolated mount config path, then sets `SFIS_PIPE_NAME` before running
`SFIS.Monitor`. Closing the Monitor stops the daemon and removes the temporary
state unless `-KeepTemp` is supplied.

Manual smoke coverage is tracked in [test notes](docs/test.md). The core path
is: connected status, server/capability/mount-config visibility, volume and
mount visibility, recursive Ephemeral temp-folder mount, selected mount
refresh, event subscription, refresh/unmount event observation, and Mount
Configs tab visibility.

Installed Windows packages launch Monitor from:

    C:\Program Files\SFIS\SFIS.Monitor\SFIS.Monitor.exe

The Windows installer can create a Start Menu shortcut with
`-CreateMonitorShortcut`.

## Optional NTFS Watch Event Smoke Test

NTFS USN watcher invalidation delivery can be checked with:

    powershell -ExecutionPolicy Bypass -File scripts/test-watch-events.ps1

This optional test requires Windows, a local fixed NTFS drive, USN journal
access, and permission to open the volume. The script starts `sfis.exe` with a
unique pipe name and includes only the temporary directory's drive, then runs
`SFIS.TestApp watch-event-smoke <temp-root>` through the C# SDK. It creates a
temporary file and expects `MountInvalidated` with `trigger = "Watch"`, a USN
reason, `changed_file_estimate > 0`, and an increased generation.

If NTFS USN watcher support is unavailable in the current environment, the
script prints `SKIPPED: NTFS USN watcher not available` and exits successfully.
It is intended for local validation and should not be treated as a mandatory CI
gate.
