# SFIS M6/M7 Stabilization Summary

This document is the stable architecture and milestone summary for the M6/M7
work. It fixes the current substrate contract before M8 Query/Index
Scalability begins.

## Overview

SFIS is now:

- Queryable: clients can use `Search`, `ListFiles`, and `GetFolderSize`.
- Mount-aware: indexing responsibility, lifecycle, refresh, watch state, and
  events are scoped to mounts.
- Persistent: Persistent mount requests can survive service restart through
  `mounts.json`.
- Reactive: clients can subscribe to live mount lifecycle and invalidation
  events over binary IPC.
- Capability-negotiated: protocol support is advertised through command, event
  type, and feature capability strings.

The service substrate is still intentionally small. Events are hints, current
state is queried explicitly, and mount scope remains the unit of policy and
lifecycle.

## M6 Reactive IPC

Reactive IPC adds server-to-client `Event` packets to binary IPC protocol v2.
The wire format remains append-only: protocol version still means wire-format
compatibility, while feature/API availability is advertised by capabilities in
the Hello response.

The public commands are:

- `Subscribe`: register the current pipe as a whole-stream mount event
  subscriber.
- `Unsubscribe`: remove the current pipe subscription and clear pending events.

The server keeps subscription state per pipe connection. A client that has not
subscribed can still issue normal requests but will not receive event packets.
Event packets use `request_id = 0` and currently carry mount events only:
`MountCreated`, `MountStatusChanged`, `MountRefreshed`, `MountRemoved`,
`MountFailed`, and `MountInvalidated`. `EventsLost` is reserved but is not
emitted.

Each subscribed pipe has a bounded pending event queue. Event publication does
not block the mount manager on slow clients. If a subscriber falls behind and
its queue overflows, SFIS closes that pipe connection and implicitly removes
the subscription. Other subscribers continue independently.

Reactive IPC is not a durable log. There is no persistence, replay cursor,
reconnect history, or guaranteed delivery while a client is disconnected.
Clients must treat events as live hints and reconcile by querying current state
with `GetStatus`, `ListMounts`, `ListMountConfigs`, `Search`, or `ListFiles`.
SDKs do not automatically reconnect subscriptions.

## M6 Query Invalidation

`MountInvalidated` is the mount-scoped query/cache invalidation event. It tells
clients that indexed state for a mount changed and that cached search results,
folder listings, mount views, or indexing queues should be invalidated.

The event is not a file-level delta stream. It does not include changed paths,
rename information, or per-query result updates. Current truth still comes from
the query APIs.

`MountInvalidated` includes:

- The mount id in the event envelope.
- `reason`, a short human-readable reason such as `initial mount ready` or
  `usn update`.
- `trigger`, one of `Watch`, `ManualRefresh`, `SchedulerRefresh`,
  `MountLifecycle`, or `Unknown`.
- `generation`, a process-local mount generation.
- `changed_file_estimate`, a coarse count for watcher batches when available.

Generation semantics:

- Generation starts at `0` for a new mount object.
- Successful initial indexing increments generation before the first lifecycle
  invalidation.
- Successful manual or scheduled refresh increments generation when indexed
  state is replaced.
- NTFS USN watcher update batches increment generation when they apply changes.
- Failed refreshes and empty/failed watcher updates do not increment
  generation.
- Generation is process-local, not persisted, and not a durable replay cursor.

Watcher consistency is intentionally mount-level. For NTFS USN updates, SFIS
updates indexed state, increments mount generation, then emits
`MountInvalidated` with `trigger = "Watch"`, `reason = "usn update"`, and a
positive `changed_file_estimate`. Clients should invalidate and query again;
they should not infer exact path deltas from the event.

## M7 Persistent Mount Config

Persistent mount configuration is stored in `mounts.json`. The default location
is the machine config path used by the service, but development and smoke tests
can override it with `SFIS_MOUNT_CONFIG_PATH`.

Persistence rules:

- Only `Persistent` policy mounts are saved.
- `Ephemeral` mounts are runtime-only and are not saved.
- Disabled config entries may exist as stored policy but do not create active
  mounts.
- Refresh interval and requester metadata are preserved for Persistent mounts.

Restore behavior:

- On service startup, SFIS loads `mounts.json` after probing volumes and before
  starting the pipe server.
- Valid enabled Persistent entries are restored as active mounts.
- Restore failures are recorded as structured config failures and exposed in
  status/config observability rather than preventing the service from starting.
- Corrupt or unavailable config files are reported in status fields.

Mount config management IPC lets clients inspect and modify persisted config:

- `ListMountConfigs`
- `RemoveMountConfig`
- `SetMountConfigEnabled`

Config persistence is part of the public substrate contract for Persistent
mounts, but it is not a general schema migration system yet.

## Test Coverage

Coverage now spans unit tests, native self-tests, and real process smoke tests.

- C# unit tests cover binary protocol compatibility, payload decoding,
  capability gating, subscription command writing, event stream behavior, and
  invalidation payload decoding.
- C++ self-tests cover store behavior, query behavior, recursive mount
  lifecycle, refresh generation, scheduler refresh, config persistence, and
  watcher invalidation manager paths.
- `scripts/test-persistent-mount.ps1` verifies Persistent mount config survives
  a real `sfis.exe` restart through the C# SDK and named pipe server.
- `scripts/test-reactive-events.ps1` verifies real process reactive delivery
  for recursive Ephemeral mount lifecycle, refresh, invalidation generation,
  unmount, and unsubscribe behavior.
- `scripts/test-watch-events.ps1` is optional and verifies NTFS USN watcher
  invalidation delivery when the environment supports opening the volume and
  using the USN journal. It exits successfully with
  `SKIPPED: NTFS USN watcher not available` when prerequisites are missing.

## Public Contracts

Mount scope is the unit of lifecycle, visibility, refresh, watch reliability,
and events. `Search`, `ListFiles`, and `GetFolderSize` operate on indexed state
inside active mount scopes. SFIS does not implicitly recursive-crawl every drive
or folder.

Access control is not per-file ACL enforcement. SFIS expects pipe access,
mount creation, and result exposure to be controlled by the embedding product
or service policy. File ACL indexing, per-client visibility filtering, and
query-time ACL filtering remain non-goals.

Protocol capability negotiation is required for optional APIs. Clients should
gate usage by advertised command, event type, and feature strings, and should
ignore capability strings they do not understand.

Event loss semantics are best-effort and connection-local. A client must assume
events may be missed after disconnect, overflow, process restart, or reconnect.
The reconciliation model is to reconnect, subscribe again, then query current
state.

Persistent config behavior applies only to Persistent mounts. Ephemeral mounts
are runtime-only, and restore failure reporting is observable but does not make
startup fail by itself.

## Known Limitations

- No durable event log or replay cursor.
- No file-level delta events or changed path delivery.
- No event filtering or query subscriptions.
- No automatic SDK reconnect.
- No per-client authentication or per-client mount visibility.
- No file ACL index or ACL-correct query results.
- No advanced query index, query planner, OR/grouping execution, or posting
  indexes.
- No global memory budget for large indexes.
- Query execution is still synchronous at the service contract level.
- No production macOS backend yet.

## M8 Preview

Next: M8 Query/Index Scalability.

Planned focus:

- Query planner.
- OR/grouping.
- Posting indexes.
- Memory budget.
- Cancellation.
- Async query execution.
