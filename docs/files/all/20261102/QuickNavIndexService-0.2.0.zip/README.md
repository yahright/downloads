# QuickNav Index Service

Windows用のファイルインデックス自動更新サービスです。Visual Studio版とVS Code版が同じ台帳とTSVを参照します。
Windowsの .NET Framework 4.7.2 以降が必要です。

## インストール / 更新

1. `QuickNavIndexService-<version>.zip` を任意のフォルダーへ展開します。4つのEXEとDLL・configは同じフォルダーに置いてください。
2. 展開先の `quicknav-index-manager.exe` を起動します。
3. 「サービス設定」→「インストール / 更新…」を選択し、UACを承認します。
4. サービスが実行中になり、通知領域にアイコンが表示されることを確認します。
5. managerでフォルダーを追加するか、「設定の取り込み」から既存のVS / VS Code設定を取り込みます。

サービスはサインイン中のユーザーごとに更新役を起動します。設定・履歴は
`%LOCALAPPDATA%\QuickNav\IndexService`、TSVの既定の出力先は
`%APPDATA%\QuickNav\FileIndex` です。登録時に出力先を指定できます。
更新時は同じ手順で新しいZIPからmanagerを実行します。登録内容とインデックスは保持されます。

## 利用

- managerで更新間隔・一時停止・「今すぐ確認」を操作できます。
- 対象に変更がなければTSVを書き換えません。使用中で差し替えできない場合は待機して再試行します。
- VSのFile Index Rootsからサービスへ移行できます。サービスの台帳に登録したルートは両拡張から参照されます。
- VS Codeでの登録・削除・再構築はmanagerから行います。サービスを使わない環境では従来のインデックス作成を利用できます。
- CLIの使い方は `quicknav-index.exe --help`、状態確認は `quicknav-index.exe list` です。

## 管理者権限を使わず試す

```powershell
.\quicknav-index.exe start
.\quicknav-index.exe register C:\src\sample --name sample --interval 60
.\quicknav-index.exe refresh --name sample --wait
.\quicknav-index.exe list
.\quicknav-index.exe stop
```

これはログイン時に自動起動しない単独workerです。Windowsサービスとしてのインストールとは別の動作です。

## アンインストール

managerの「サービス設定」→「アンインストール…」でサービス登録を削除できます。
登録内容・履歴・TSVは残ります。従来の拡張側の管理へ戻す場合はworkerを停止し、
`%LOCALAPPDATA%\QuickNav\IndexService\registry.json` を別の場所へ退避してください。
