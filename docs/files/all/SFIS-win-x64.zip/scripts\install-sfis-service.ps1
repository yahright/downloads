[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string]$SfisExePath,

    [string]$ServiceName = "SFIS",
    [string]$DisplayName = "SFIS File Index Service",
    [string]$PipeName = "sfis",
    [string]$IndexPath,
    [switch]$DisableRecursiveFallback,
    [switch]$IncludeNetworkVolumes,
    [string[]]$IncludeVolume = @(),
    [string[]]$ExcludeVolume = @()
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Invoke-Sc {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    & sc.exe @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "sc.exe $($Arguments -join ' ') failed with exit code $LASTEXITCODE."
    }
}

function Quote-CommandPart {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Value
    )

    return '"' + ($Value -replace '"', '\"') + '"'
}

if (-not (Test-IsAdministrator)) {
    throw "This script must be run from an elevated PowerShell session."
}

if ([string]::IsNullOrWhiteSpace($SfisExePath)) {
    $repoRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "..")).ProviderPath
    $SfisExePath = Join-Path $repoRoot "build\Release\sfis.exe"
}

try {
    $resolvedExePath = (Resolve-Path -LiteralPath $SfisExePath).ProviderPath
}
catch {
    throw "sfis.exe was not found: $SfisExePath"
}

if (-not (Test-Path -LiteralPath $resolvedExePath -PathType Leaf)) {
    throw "sfis.exe path is not a file: $resolvedExePath"
}

$binPathParts = @(
    (Quote-CommandPart $resolvedExePath),
    "--service",
    "--service-name",
    (Quote-CommandPart $ServiceName),
    "--pipe-name",
    (Quote-CommandPart $PipeName)
)
if (-not [string]::IsNullOrWhiteSpace($IndexPath)) {
    $binPathParts += @("--index-path", (Quote-CommandPart $IndexPath))
}
if ($DisableRecursiveFallback) {
    $binPathParts += "--disable-recursive-fallback"
}
else {
    $binPathParts += "--enable-recursive-fallback"
}
if ($IncludeNetworkVolumes) {
    $binPathParts += "--include-network-volumes"
}
foreach ($volume in $IncludeVolume) {
    if (-not [string]::IsNullOrWhiteSpace($volume)) {
        $binPathParts += @("--include-volume", (Quote-CommandPart $volume))
    }
}
foreach ($volume in $ExcludeVolume) {
    if (-not [string]::IsNullOrWhiteSpace($volume)) {
        $binPathParts += @("--exclude-volume", (Quote-CommandPart $volume))
    }
}
$binPath = $binPathParts -join " "
$existing = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($null -eq $existing) {
    Invoke-Sc -Arguments @(
        "create",
        $ServiceName,
        "binPath=",
        $binPath,
        "start=",
        "auto",
        "DisplayName=",
        $DisplayName
    )
}
else {
    if ($existing.Status -ne "Stopped") {
        Invoke-Sc -Arguments @("stop", $ServiceName)
        $existing.WaitForStatus("Stopped", [TimeSpan]::FromSeconds(30))
    }

    Invoke-Sc -Arguments @(
        "config",
        $ServiceName,
        "binPath=",
        $binPath,
        "start=",
        "auto",
        "DisplayName=",
        $DisplayName
    )
}

Invoke-Sc -Arguments @("description", $ServiceName, $DisplayName)
Invoke-Sc -Arguments @(
    "failure",
    $ServiceName,
    "reset=",
    "86400",
    "actions=",
    "restart/5000/restart/30000/none/0"
)

Write-Host "Installed service '$ServiceName'."
Write-Host "Executable: $resolvedExePath"
Write-Host "PipeName: $PipeName"
if (-not [string]::IsNullOrWhiteSpace($IndexPath)) {
    Write-Host "IndexPath: $IndexPath"
}
Write-Host "RecursiveFallback: $(-not $DisableRecursiveFallback)"
Write-Host "IncludeNetworkVolumes: $IncludeNetworkVolumes"
if ($IncludeVolume.Count -gt 0) {
    Write-Host "IncludeVolume: $($IncludeVolume -join ', ')"
}
if ($ExcludeVolume.Count -gt 0) {
    Write-Host "ExcludeVolume: $($ExcludeVolume -join ', ')"
}
Write-Host "BinPath: $binPath"
