Scopy Windows x64 package

Run Scopy.Gui.exe or run-scopy-gui.bat to start the GUI.
The bundled CLI is at scopy\scopy.exe and is auto-detected by the GUI.

Built configuration: Release
Runtime: win-x64
Self-contained: false
