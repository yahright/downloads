param(
    [string]$SfisExe = "",
    [string]$TestAppProject = "",
    [switch]$KeepTemp
)

$ErrorActionPreference = "Stop"

function Resolve-RepoRoot {
    return (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
}

function Quote-Arg([string]$Value) {
    return '"' + ($Value -replace '"', '\"') + '"'
}

function Resolve-DefaultSfisExe([string]$RepoRoot) {
    $candidates = @(
        (Join-Path $RepoRoot "build\ARM64\Release\sfis.exe"),
        (Join-Path $RepoRoot "build\x64\Release\sfis.exe"),
        (Join-Path $RepoRoot "build\Release\sfis.exe")
    )
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) {
            return $candidate
        }
    }
    return $candidates[0]
}

function New-SfisProcess(
    [string]$PipeName,
    [string]$IndexPath,
    [string]$MountConfigPath,
    [string]$StdOutPath,
    [string]$StdErrPath) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $script:SfisExe
    $quotedArgs = @(
        "--allow-multiple",
        "--pipe-name", $PipeName,
        "--index-path", $IndexPath,
        "--include-volume", "__SFIS_REACTIVE_EVENT_SMOKE_NO_AUTO_VOLUME__"
    ) | ForEach-Object { Quote-Arg $_ }
    $psi.Arguments = $quotedArgs -join " "
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.Environment["SFIS_MOUNT_CONFIG_PATH"] = $MountConfigPath

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi
    if (-not $process.Start()) {
        throw "failed to start sfis.exe"
    }
    $process.BeginOutputReadLine()
    $process.BeginErrorReadLine()
    Register-ObjectEvent -InputObject $process -EventName OutputDataReceived -Action {
        if ($EventArgs.Data -ne $null) {
            Add-Content -LiteralPath $Event.MessageData.StdOut -Value $EventArgs.Data
        }
    } -MessageData @{ StdOut = $StdOutPath } | Out-Null
    Register-ObjectEvent -InputObject $process -EventName ErrorDataReceived -Action {
        if ($EventArgs.Data -ne $null) {
            Add-Content -LiteralPath $Event.MessageData.StdErr -Value $EventArgs.Data
        }
    } -MessageData @{ StdErr = $StdErrPath } | Out-Null
    return $process
}

function Stop-SfisProcess($Process) {
    if ($null -eq $Process) {
        return
    }
    if (-not $Process.HasExited) {
        Stop-Process -Id $Process.Id -Force -ErrorAction SilentlyContinue
        $Process.WaitForExit(5000) | Out-Null
    }
}

function Invoke-TestApp([string[]]$Arguments) {
    $oldPipe = $env:SFIS_PIPE_NAME
    try {
        $env:SFIS_PIPE_NAME = $script:PipeName
        if (Test-Path -LiteralPath $script:TestAppDll) {
            $output = & dotnet $script:TestAppDll @Arguments 2>&1
        } else {
            $output = & dotnet run --project $script:TestAppProject --configuration Release -- @Arguments 2>&1
        }
        $text = ($output | Out-String).Trim()
        if ($LASTEXITCODE -ne 0) {
            throw "TestApp failed ($($Arguments -join ' ')) exit=$LASTEXITCODE`n$text"
        }
        return $text
    } finally {
        $env:SFIS_PIPE_NAME = $oldPipe
    }
}

function Wait-ForReady {
    param([int]$TimeoutSeconds = 30)

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    $last = ""
    while ((Get-Date) -lt $deadline) {
        try {
            $last = Invoke-TestApp @("status")
            if ($last -match "state=ready") {
                return $last
            }
        } catch {
            $last = $_.Exception.Message
        }
        Start-Sleep -Milliseconds 500
    }
    throw "sfis pipe did not become ready within $TimeoutSeconds seconds. Last output:`n$last"
}

function Assert-MatchText([string]$Text, [string]$Pattern, [string]$Message) {
    if ($Text -notmatch $Pattern) {
        throw "$Message`nPattern: $Pattern`nOutput:`n$Text"
    }
}

$repoRoot = Resolve-RepoRoot
if ([string]::IsNullOrWhiteSpace($SfisExe)) {
    $SfisExe = Resolve-DefaultSfisExe $repoRoot
}
if ([string]::IsNullOrWhiteSpace($TestAppProject)) {
    $TestAppProject = Join-Path $repoRoot "SFIS.TestApp\SFIS.TestApp.csproj"
}
$SfisExe = (Resolve-Path $SfisExe).Path
$TestAppProject = (Resolve-Path $TestAppProject).Path
$script:SfisExe = $SfisExe
$script:TestAppProject = $TestAppProject
$script:TestAppDll = Join-Path $repoRoot "SFIS.TestApp\bin\Release\net8.0\SFIS.TestApp.dll"
$script:PipeName = "sfis-events-smoke-$PID-$([Guid]::NewGuid().ToString('N').Substring(0, 8))"

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) "sfis-reactive-events-smoke-$PID-$([Guid]::NewGuid().ToString('N'))"
$mountRoot = Join-Path $tempRoot "mount-root"
$indexPath = Join-Path $tempRoot "index\sfis-index-v1.bin"
$mountConfigPath = Join-Path $tempRoot "programdata\SFIS\mounts.json"
$stdout = Join-Path $tempRoot "sfis.out.log"
$stderr = Join-Path $tempRoot "sfis.err.log"
$process = $null

try {
    New-Item -ItemType Directory -Force -Path $mountRoot | Out-Null
    New-Item -ItemType Directory -Force -Path (Join-Path $mountRoot "subdir") | Out-Null
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $indexPath) | Out-Null
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $mountConfigPath) | Out-Null
    Set-Content -LiteralPath (Join-Path $mountRoot "file.txt") -Value "reactive event smoke test" -Encoding ASCII
    Set-Content -LiteralPath (Join-Path $mountRoot "subdir\nested.txt") -Value "nested" -Encoding ASCII

    Write-Host "[reactive-events-smoke] temp=$tempRoot"
    Write-Host "[reactive-events-smoke] pipe=$script:PipeName"

    $process = New-SfisProcess $script:PipeName $indexPath $mountConfigPath $stdout $stderr
    Wait-ForReady | Out-Null

    $output = Invoke-TestApp @("event-smoke", $mountRoot)
    Write-Host $output
    Assert-MatchText $output "\[event-smoke\] passed" "event-smoke did not report success"
    Assert-MatchText $output "event_stream=clean_after_unsubscribe" "event stream did not exit cleanly"
    Assert-MatchText $output "initial_generation=([1-9][0-9]*)" "initial invalidation generation was missing"
    Assert-MatchText $output "refresh_generation=([1-9][0-9]*)" "refresh invalidation generation was missing"

    Write-Host "[reactive-events-smoke] passed"
} finally {
    Stop-SfisProcess $process
    if (-not $KeepTemp) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    } else {
        Write-Host "[reactive-events-smoke] kept temp=$tempRoot"
    }
}
