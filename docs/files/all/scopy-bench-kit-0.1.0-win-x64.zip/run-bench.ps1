<#
.SYNOPSIS
  SCOPY portable benchmark runner. Generates reproducible datasets with
  `scopy gen`, then copies them with SCOPY, Robocopy, and (optionally) FastCopy,
  measuring wall-clock throughput. Discards a warmup run and reports the median
  over N runs so results are comparable across machines.

.DESCRIPTION
  This is the field benchmark kit's entry point. Run it on any Windows machine
  to produce a CSV plus a side-by-side comparison table. Wall-clock time is the
  fair metric (it includes process startup, open, transfer, flush, and close).

.EXAMPLE
  pwsh ./run-bench.ps1 -DataRoot C:\scopy-bench\src -DestRoot D:\scopy-bench\dst

.EXAMPLE
  pwsh ./run-bench.ps1 -DataRoot C:\b\src -DestRoot D:\b\dst `
      -Presets small-files,large-single -Repeat 7 -FastCopyExe C:\Tools\FastCopy.exe
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [string] $DataRoot,
    [Parameter(Mandatory = $true)] [string] $DestRoot,
    [string[]] $Presets = @("small-files", "large-single", "multi-large", "mixed-tree"),
    [int] $Repeat = 7,
    [int] $Warmup = 1,
    [string] $ScopyExe,
    [string] $FastCopyExe,
    [switch] $NoRobocopy,
    [int] $Mt = 16,
    [string] $LargeSize = "1GiB",
    [int] $SmallCount = 10000,
    [int] $Seed = 0,
    [string] $OutputCsv,
    [string[]] $ScopyArgs = @("--overwrite", "overwrite", "--progress", "none", "--output", "json")
)

$ErrorActionPreference = "Stop"

# --- Resolve tools ---------------------------------------------------------
if (-not $ScopyExe) {
    $candidate = Join-Path $PSScriptRoot "scopy.exe"
    if (Test-Path $candidate) { $ScopyExe = $candidate }
    else { $ScopyExe = (Get-Command scopy.exe -ErrorAction SilentlyContinue)?.Source }
}
if (-not $ScopyExe -or -not (Test-Path $ScopyExe)) {
    throw "scopy.exe not found. Pass -ScopyExe <path> or place scopy.exe next to this script."
}
$ScopyExe = (Resolve-Path $ScopyExe).Path

$tools = @("scopy")
if (-not $NoRobocopy) { $tools += "robocopy" }
if ($FastCopyExe -and (Test-Path $FastCopyExe)) {
    $FastCopyExe = (Resolve-Path $FastCopyExe).Path
    $tools += "fastcopy"
} elseif ($FastCopyExe) {
    Write-Warning "FastCopy not found at '$FastCopyExe'; skipping FastCopy."
}

if (-not $OutputCsv) {
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $OutputCsv = Join-Path (Get-Location) "bench-$stamp.csv"
}

Write-Host "SCOPY  : $ScopyExe"
Write-Host "Tools  : $($tools -join ', ')"
Write-Host "Presets: $($Presets -join ', ')"
Write-Host "Repeat : $Repeat (+$Warmup warmup), median reported"
Write-Host "Machine: $env:COMPUTERNAME / $([Environment]::ProcessorCount) logical CPUs"
Write-Host "Output : $OutputCsv"
Write-Host ""

# --- Generate datasets -----------------------------------------------------
Write-Host "Generating datasets under $DataRoot ..."
$genArgs = @("gen", $DataRoot, "--preset", ($Presets -join ","),
    "--large-size", $LargeSize, "--small-count", "$SmallCount", "--seed", "$Seed")
& $ScopyExe @genArgs
if ($LASTEXITCODE -ne 0) { throw "scopy gen failed (exit $LASTEXITCODE)." }

# --- Helpers ---------------------------------------------------------------
function Get-TreeStats {
    param([string] $Path)
    $files = Get-ChildItem -Recurse -File -LiteralPath $Path -ErrorAction SilentlyContinue
    $bytes = ($files | Measure-Object -Property Length -Sum).Sum
    [pscustomobject]@{ Files = $files.Count; Bytes = [uint64]($bytes ?? 0) }
}

function Reset-Destination {
    param([string] $Path)
    if (Test-Path -LiteralPath $Path) {
        Remove-Item -Recurse -Force -LiteralPath $Path
    }
    # Wait for the delete to actually settle so it doesn't bleed into timing.
    $deadline = [DateTime]::UtcNow.AddSeconds(30)
    while ((Test-Path -LiteralPath $Path) -and [DateTime]::UtcNow -lt $deadline) {
        Start-Sleep -Milliseconds 50
    }
    # SCOPY treats a missing destination parent as invalid (-403), while
    # Robocopy/FastCopy auto-create it. Ensure the parent exists so every tool
    # competes on copy throughput, not parent-dir creation semantics.
    $parent = Split-Path -Parent $Path
    if ($parent -and -not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }
}

function Invoke-CopyOnce {
    param([string] $Tool, [string] $Src, [string] $Dst)
    Reset-Destination $Dst
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    switch ($Tool) {
        "scopy" {
            & $ScopyExe copy $Src $Dst @ScopyArgs | Out-Null
            $ok = ($LASTEXITCODE -eq 0)
        }
        "robocopy" {
            & robocopy $Src $Dst /E /COPY:DAT /R:0 /W:0 /MT:$Mt /NFL /NDL /NP /NJH /NJS /NC /BYTES | Out-Null
            # Robocopy exit codes < 8 are success.
            $ok = ($LASTEXITCODE -lt 8)
        }
        "fastcopy" {
            & $FastCopyExe /cmd=force_copy /no_ui /auto_close /force_close /estimate=FALSE $Src /to=$Dst | Out-Null
            $ok = ($LASTEXITCODE -eq 0)
        }
    }
    $sw.Stop()
    [pscustomobject]@{ Ok = $ok; ElapsedMs = $sw.Elapsed.TotalMilliseconds }
}

function Get-Median {
    param([double[]] $Values)
    if ($Values.Count -eq 0) { return $null }
    $sorted = $Values | Sort-Object
    $mid = [math]::Floor($sorted.Count / 2)
    if ($sorted.Count % 2 -eq 1) { return $sorted[$mid] }
    return ($sorted[$mid - 1] + $sorted[$mid]) / 2
}

# --- Run -------------------------------------------------------------------
$rows = New-Object System.Collections.Generic.List[object]
$summary = New-Object System.Collections.Generic.List[object]

foreach ($preset in $Presets) {
    $src = Join-Path $DataRoot $preset
    if (-not (Test-Path -LiteralPath $src)) {
        Write-Warning "Dataset '$preset' not found at $src; skipping."
        continue
    }
    $stats = Get-TreeStats $src
    Write-Host ("`n=== {0}  ({1} files, {2:N1} MiB) ===" -f $preset, $stats.Files, ($stats.Bytes / 1MB))

    foreach ($tool in $tools) {
        $dst = Join-Path $DestRoot $preset
        $samples = New-Object System.Collections.Generic.List[double]
        $failed = $false
        for ($i = 0; $i -lt ($Warmup + $Repeat); $i++) {
            $r = Invoke-CopyOnce -Tool $tool -Src $src -Dst $dst
            if (-not $r.Ok) { $failed = $true; break }
            $isWarmup = ($i -lt $Warmup)
            if (-not $isWarmup) {
                $samples.Add($r.ElapsedMs)
                $rows.Add([pscustomobject]@{
                        machine = $env:COMPUTERNAME; tool = $tool; preset = $preset
                        run = ($i - $Warmup + 1); elapsed_ms = [math]::Round($r.ElapsedMs, 1)
                        files = $stats.Files; bytes = $stats.Bytes
                        mb_per_s = [math]::Round($stats.Bytes / ($r.ElapsedMs / 1000) / 1MB, 1)
                    })
            }
        }
        Reset-Destination $dst
        if ($failed) {
            Write-Host ("  {0,-9}: FAILED" -f $tool)
            continue
        }
        $median = Get-Median ($samples.ToArray())
        $mbps = $stats.Bytes / ($median / 1000) / 1MB
        $fps = $stats.Files / ($median / 1000)
        $summary.Add([pscustomobject]@{
                preset = $preset; tool = $tool
                median_ms = [math]::Round($median, 1)
                mb_per_s = [math]::Round($mbps, 1)
                files_per_s = [math]::Round($fps, 0)
            })
        Write-Host ("  {0,-9}: median {1,8:N1} ms   {2,8:N1} MiB/s   {3,9:N0} files/s" -f $tool, $median, $mbps, $fps)
    }
}

# --- Output ----------------------------------------------------------------
$rows | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8
Write-Host "`nRaw samples written to: $OutputCsv"

Write-Host "`n=== Summary (median, relative to FastCopy where available) ==="
foreach ($preset in ($summary | Select-Object -ExpandProperty preset -Unique)) {
    $group = $summary | Where-Object preset -eq $preset
    $baseline = ($group | Where-Object tool -eq "fastcopy" | Select-Object -First 1).mb_per_s
    Write-Host "`n[$preset]"
    foreach ($s in ($group | Sort-Object -Property mb_per_s -Descending)) {
        $rel = if ($baseline) { " (x{0:N2} vs FastCopy)" -f ($s.mb_per_s / $baseline) } else { "" }
        Write-Host ("  {0,-9}: {1,8:N1} MiB/s   {2,9:N0} files/s{3}" -f $s.tool, $s.mb_per_s, $s.files_per_s, $rel)
    }
}
Write-Host ""
# Robocopy reports success with exit codes 1-7, which would otherwise leak into
# this script's exit code. Report success explicitly.
exit 0
