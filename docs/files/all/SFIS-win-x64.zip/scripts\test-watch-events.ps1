param(
    [string]$SfisExe = "",
    [string]$TestAppProject = "",
    [switch]$KeepTemp
)

$ErrorActionPreference = "Stop"

function Resolve-RepoRoot {
    return (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
}

function Quote-Arg([string]$Value) {
    return '"' + ($Value -replace '"', '\"') + '"'
}

function Resolve-DefaultSfisExe([string]$RepoRoot) {
    $candidates = @(
        (Join-Path $RepoRoot "build\ARM64\Release\sfis.exe"),
        (Join-Path $RepoRoot "build\x64\Release\sfis.exe"),
        (Join-Path $RepoRoot "build\Release\sfis.exe")
    )
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) {
            return $candidate
        }
    }
    return $candidates[0]
}

function Get-DriveRootForPath([string]$Path) {
    $fullPath = [System.IO.Path]::GetFullPath($Path)
    return [System.IO.Path]::GetPathRoot($fullPath)
}

function New-SfisProcess(
    [string]$PipeName,
    [string]$IndexPath,
    [string]$MountConfigPath,
    [string]$IncludeVolume,
    [string]$StdOutPath,
    [string]$StdErrPath) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $script:SfisExe
    $quotedArgs = @(
        "--allow-multiple",
        "--pipe-name", $PipeName,
        "--index-path", $IndexPath,
        "--include-volume", $IncludeVolume
    ) | ForEach-Object { Quote-Arg $_ }
    $psi.Arguments = $quotedArgs -join " "
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.Environment["SFIS_MOUNT_CONFIG_PATH"] = $MountConfigPath

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi
    if (-not $process.Start()) {
        throw "failed to start sfis.exe"
    }
    $process.BeginOutputReadLine()
    $process.BeginErrorReadLine()
    Register-ObjectEvent -InputObject $process -EventName OutputDataReceived -Action {
        if ($EventArgs.Data -ne $null) {
            Add-Content -LiteralPath $Event.MessageData.StdOut -Value $EventArgs.Data
        }
    } -MessageData @{ StdOut = $StdOutPath } | Out-Null
    Register-ObjectEvent -InputObject $process -EventName ErrorDataReceived -Action {
        if ($EventArgs.Data -ne $null) {
            Add-Content -LiteralPath $Event.MessageData.StdErr -Value $EventArgs.Data
        }
    } -MessageData @{ StdErr = $StdErrPath } | Out-Null
    return $process
}

function Stop-SfisProcess($Process) {
    if ($null -eq $Process) {
        return
    }
    if (-not $Process.HasExited) {
        Stop-Process -Id $Process.Id -Force -ErrorAction SilentlyContinue
        $Process.WaitForExit(5000) | Out-Null
    }
}

function Invoke-TestApp([string[]]$Arguments) {
    $oldPipe = $env:SFIS_PIPE_NAME
    try {
        $env:SFIS_PIPE_NAME = $script:PipeName
        if (Test-Path -LiteralPath $script:TestAppDll) {
            $output = & dotnet $script:TestAppDll @Arguments 2>&1
        } else {
            $output = & dotnet run --project $script:TestAppProject --configuration Release -- @Arguments 2>&1
        }
        $text = ($output | Out-String).Trim()
        if ($LASTEXITCODE -ne 0) {
            throw "TestApp failed ($($Arguments -join ' ')) exit=$LASTEXITCODE`n$text"
        }
        return $text
    } finally {
        $env:SFIS_PIPE_NAME = $oldPipe
    }
}

function Wait-ForReady {
    param([int]$TimeoutSeconds = 180)

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    $last = ""
    while ((Get-Date) -lt $deadline) {
        try {
            $last = Invoke-TestApp @("status")
            if ($last -match "state=ready") {
                return $last
            }
        } catch {
            $last = $_.Exception.Message
        }
        Start-Sleep -Milliseconds 1000
    }
    throw "sfis pipe did not become ready within $TimeoutSeconds seconds. Last output:`n$last"
}

function Assert-MatchText([string]$Text, [string]$Pattern, [string]$Message) {
    if ($Text -notmatch $Pattern) {
        throw "$Message`nPattern: $Pattern`nOutput:`n$Text"
    }
}

$repoRoot = Resolve-RepoRoot
if ([string]::IsNullOrWhiteSpace($SfisExe)) {
    $SfisExe = Resolve-DefaultSfisExe $repoRoot
}
if ([string]::IsNullOrWhiteSpace($TestAppProject)) {
    $TestAppProject = Join-Path $repoRoot "SFIS.TestApp\SFIS.TestApp.csproj"
}
$SfisExe = (Resolve-Path $SfisExe).Path
$TestAppProject = (Resolve-Path $TestAppProject).Path
$script:SfisExe = $SfisExe
$script:TestAppProject = $TestAppProject
$script:TestAppDll = Join-Path $repoRoot "SFIS.TestApp\bin\Release\net8.0\SFIS.TestApp.dll"
$script:PipeName = "sfis-watch-events-$PID-$([Guid]::NewGuid().ToString('N').Substring(0, 8))"

$tempBase = [System.IO.Path]::GetTempPath()
$driveRoot = Get-DriveRootForPath $tempBase
$drive = New-Object System.IO.DriveInfo($driveRoot)
if ($drive.DriveFormat -ne "NTFS" -or $drive.DriveType -ne [System.IO.DriveType]::Fixed) {
    Write-Host "SKIPPED: NTFS USN watcher not available"
    exit 0
}
$includeVolume = $driveRoot.TrimEnd([char]'\')

$tempRoot = Join-Path $tempBase "sfis-watch-events-smoke-$PID-$([Guid]::NewGuid().ToString('N'))"
$mountRoot = Join-Path $tempRoot "watch-root"
$indexPath = Join-Path $tempRoot "index\sfis-index-v1.bin"
$mountConfigPath = Join-Path $tempRoot "programdata\SFIS\mounts.json"
$stdout = Join-Path $tempRoot "sfis.out.log"
$stderr = Join-Path $tempRoot "sfis.err.log"
$process = $null

try {
    New-Item -ItemType Directory -Force -Path $mountRoot | Out-Null
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $indexPath) | Out-Null
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $mountConfigPath) | Out-Null

    Write-Host "[watch-events-smoke] temp=$tempRoot"
    Write-Host "[watch-events-smoke] pipe=$script:PipeName"
    Write-Host "[watch-events-smoke] include_volume=$includeVolume"

    $process = New-SfisProcess $script:PipeName $indexPath $mountConfigPath $includeVolume $stdout $stderr
    Wait-ForReady | Out-Null

    $output = Invoke-TestApp @("watch-event-smoke", $mountRoot)
    Write-Host $output
    if ($output -match "SKIPPED: NTFS USN watcher not available") {
        Write-Host "[watch-events-smoke] skipped"
        exit 0
    }

    Assert-MatchText $output "\[watch-event-smoke\] passed" "watch-event-smoke did not report success"
    Assert-MatchText $output "create_generation=([1-9][0-9]*)" "watch invalidation generation was missing"
    Assert-MatchText $output "changed=([1-9][0-9]*)" "watch invalidation changed estimate was missing"
    Assert-MatchText $output "trigger=Watch" "watch invalidation trigger was missing"

    Write-Host "[watch-events-smoke] passed"
} finally {
    Stop-SfisProcess $process
    if (-not $KeepTemp) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    } else {
        Write-Host "[watch-events-smoke] kept temp=$tempRoot"
    }
}
