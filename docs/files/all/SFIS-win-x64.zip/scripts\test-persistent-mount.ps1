param(
    [string]$SfisExe = "",
    [string]$TestAppProject = "",
    [UInt64]$RefreshIntervalMs = 5000,
    [switch]$KeepTemp
)

$ErrorActionPreference = "Stop"

function Resolve-RepoRoot {
    return (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
}

function Quote-Arg([string]$Value) {
    return '"' + ($Value -replace '"', '\"') + '"'
}

function New-SfisProcess([string]$PipeName, [string]$IndexPath, [string]$MountConfigPath, [string]$StdOutPath, [string]$StdErrPath) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $script:SfisExe
    $quotedArgs = @(
        "--allow-multiple",
        "--pipe-name", $PipeName,
        "--index-path", $IndexPath,
        "--include-volume", "__SFIS_PERSISTENT_MOUNT_SMOKE_NO_AUTO_VOLUME__"
    ) | ForEach-Object { Quote-Arg $_ }
    $psi.Arguments = $quotedArgs -join " "
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.Environment["SFIS_MOUNT_CONFIG_PATH"] = $MountConfigPath

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi
    if (-not $process.Start()) {
        throw "failed to start sfis.exe"
    }
    $process.BeginOutputReadLine()
    $process.BeginErrorReadLine()
    Register-ObjectEvent -InputObject $process -EventName OutputDataReceived -Action {
        if ($EventArgs.Data -ne $null) {
            Add-Content -LiteralPath $Event.MessageData.StdOut -Value $EventArgs.Data
        }
    } -MessageData @{ StdOut = $StdOutPath } | Out-Null
    Register-ObjectEvent -InputObject $process -EventName ErrorDataReceived -Action {
        if ($EventArgs.Data -ne $null) {
            Add-Content -LiteralPath $Event.MessageData.StdErr -Value $EventArgs.Data
        }
    } -MessageData @{ StdErr = $StdErrPath } | Out-Null
    return $process
}

function Stop-SfisProcess($Process) {
    if ($null -eq $Process) {
        return
    }
    if (-not $Process.HasExited) {
        Stop-Process -Id $Process.Id -Force -ErrorAction SilentlyContinue
        $Process.WaitForExit(5000) | Out-Null
    }
}

function Invoke-TestApp([string[]]$Arguments) {
    $oldPipe = $env:SFIS_PIPE_NAME
    try {
        $env:SFIS_PIPE_NAME = $script:PipeName
        if (Test-Path -LiteralPath $script:TestAppDll) {
            $output = & dotnet $script:TestAppDll @Arguments 2>&1
        } else {
            $output = & dotnet run --project $script:TestAppProject --configuration Release -- @Arguments 2>&1
        }
        $text = ($output | Out-String).Trim()
        if ($LASTEXITCODE -ne 0) {
            throw "TestApp failed ($($Arguments -join ' ')) exit=$LASTEXITCODE`n$text"
        }
        return $text
    } finally {
        $env:SFIS_PIPE_NAME = $oldPipe
    }
}

function Wait-ForReady {
    param([int]$TimeoutSeconds = 30)

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    $last = ""
    while ((Get-Date) -lt $deadline) {
        try {
            $last = Invoke-TestApp @("status")
            if ($last -match "state=ready") {
                return $last
            }
        } catch {
            $last = $_.Exception.Message
        }
        Start-Sleep -Milliseconds 500
    }
    throw "sfis pipe did not become ready within $TimeoutSeconds seconds. Last output:`n$last"
}

function Assert-MatchText([string]$Text, [string]$Pattern, [string]$Message) {
    $match = [regex]::Match($Text, $Pattern)
    if (-not $match.Success) {
        throw "$Message`nPattern: $Pattern`nOutput:`n$Text"
    }
    $script:LastMatch = $match
}

function Assert-FileExists([string]$Path, [string]$Message) {
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "$Message`nMissing: $Path"
    }
}

$repoRoot = Resolve-RepoRoot
if ([string]::IsNullOrWhiteSpace($SfisExe)) {
    $SfisExe = Join-Path $repoRoot "build\ARM64\Release\sfis.exe"
}
if ([string]::IsNullOrWhiteSpace($TestAppProject)) {
    $TestAppProject = Join-Path $repoRoot "SFIS.TestApp\SFIS.TestApp.csproj"
}
$SfisExe = (Resolve-Path $SfisExe).Path
$TestAppProject = (Resolve-Path $TestAppProject).Path
$script:SfisExe = $SfisExe
$script:TestAppProject = $TestAppProject
$script:TestAppDll = Join-Path $repoRoot "SFIS.TestApp\bin\Release\net8.0\SFIS.TestApp.dll"
$script:PipeName = "sfis-persistent-smoke-$PID-$([Guid]::NewGuid().ToString('N').Substring(0, 8))"

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) "sfis-persistent-mount-smoke-$PID-$([Guid]::NewGuid().ToString('N'))"
$mountRoot = Join-Path $tempRoot "mount-root"
$indexPath = Join-Path $tempRoot "index\sfis-index-v1.bin"
$mountConfigPath = Join-Path $tempRoot "programdata\SFIS\mounts.json"
$stdout1 = Join-Path $tempRoot "sfis-1.out.log"
$stderr1 = Join-Path $tempRoot "sfis-1.err.log"
$stdout2 = Join-Path $tempRoot "sfis-2.out.log"
$stderr2 = Join-Path $tempRoot "sfis-2.err.log"
$process = $null

try {
    New-Item -ItemType Directory -Force -Path $mountRoot | Out-Null
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $indexPath) | Out-Null
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $mountConfigPath) | Out-Null
    Set-Content -LiteralPath (Join-Path $mountRoot "file.txt") -Value "persistent mount smoke test" -Encoding ASCII

    Write-Host "[persistent-mount-smoke] temp=$tempRoot"
    Write-Host "[persistent-mount-smoke] pipe=$script:PipeName"

    $process = New-SfisProcess $script:PipeName $indexPath $mountConfigPath $stdout1 $stderr1
    Wait-ForReady | Out-Null

    $mountOutput = Invoke-TestApp @("mount", $mountRoot, "recursive", "Persistent")
    Assert-MatchText $mountOutput "mount_id=([^ ]+)" "mount command did not return a mount_id"
    $mountId = $script:LastMatch.Groups[1].Value

    $intervalOutput = Invoke-TestApp @("set-refresh-interval", $mountId, "$RefreshIntervalMs")
    Assert-MatchText $intervalOutput "refresh_interval_ms=$RefreshIntervalMs\b" "refresh interval was not applied"

    Assert-FileExists $mountConfigPath "mount config file was not created"
    $configsBefore = Invoke-TestApp @("mount-configs")
    Assert-MatchText $configsBefore "root_path=`"[^`"]*mount-root`"" "mount-configs did not include mounted root"
    Assert-MatchText $configsBefore "refresh_interval_ms=$RefreshIntervalMs\b" "mount-configs did not include refresh interval"
    Assert-MatchText $configsBefore "enabled=yes" "mount-configs did not show enabled config"

    Stop-SfisProcess $process
    $process = $null

    $process = New-SfisProcess $script:PipeName $indexPath $mountConfigPath $stdout2 $stderr2
    $statusAfterRestart = Wait-ForReady
    Assert-MatchText $statusAfterRestart "mount_config_loaded=yes" "status did not report loaded mount config"
    Assert-MatchText $statusAfterRestart "mount_config_restored=([1-9][0-9]*)" "status did not report restored mount config"
    Assert-MatchText $statusAfterRestart "mount_config_failed=0\b" "status reported restore failures"

    $mountsAfterRestart = Invoke-TestApp @("list-mounts")
    Assert-MatchText $mountsAfterRestart "root=`"[^`"]*mount-root`"" "list-mounts did not include restored mount"
    Assert-MatchText $mountsAfterRestart "refresh_interval_ms=$RefreshIntervalMs\b" "restored mount did not keep refresh interval"

    $configsAfterRestart = Invoke-TestApp @("mount-configs")
    Assert-MatchText $configsAfterRestart "root_path=`"[^`"]*mount-root`"" "mount-configs did not include config after restart"
    Assert-MatchText $configsAfterRestart "enabled=yes" "config was not enabled after restart"

    $removeOutput = Invoke-TestApp @("remove-mount-config", $mountRoot, "recursive", "Persistent")
    Assert-MatchText $removeOutput "removed=yes" "remove-mount-config did not remove config"

    Write-Host "[persistent-mount-smoke] passed"
} finally {
    Stop-SfisProcess $process
    if (-not $KeepTemp) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    } else {
        Write-Host "[persistent-mount-smoke] kept temp=$tempRoot"
    }
}
