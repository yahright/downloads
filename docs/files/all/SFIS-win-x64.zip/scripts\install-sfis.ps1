[CmdletBinding()]
param(
    [string]$PackageRoot,
    [string]$InstallDir = "$env:ProgramFiles\SFIS",
    [string]$DataDir = "$env:ProgramData\SFIS",
    [string]$ServiceName = "SFIS",
    [string]$DisplayName = "SFIS Filesystem Indexing Service",
    [switch]$ResetIndex,
    [switch]$NoStart,
    [switch]$Verify,
    [switch]$CreateMonitorShortcut
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Resolve-PackageRoot {
    param([string]$Value)

    if (-not [string]::IsNullOrWhiteSpace($Value)) {
        return (Resolve-Path -LiteralPath $Value).ProviderPath
    }

    $scriptDir = (Resolve-Path -LiteralPath $PSScriptRoot).ProviderPath
    $parent = Split-Path -Parent $scriptDir
    if (Test-Path -LiteralPath (Join-Path $parent "bin\sfis.exe") -PathType Leaf) {
        return $parent
    }

    return (Resolve-Path -LiteralPath (Join-Path $scriptDir "..")).ProviderPath
}

function Resolve-SourceFile {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Root,
        [Parameter(Mandatory = $true)]
        [string[]]$RelativePaths,
        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    foreach ($relativePath in $RelativePaths) {
        $candidate = Join-Path $Root $relativePath
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return (Resolve-Path -LiteralPath $candidate).ProviderPath
        }
    }

    throw "$Name was not found under package root '$Root'."
}

function Invoke-Sc {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)

    & sc.exe @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "sc.exe $($Arguments -join ' ') failed with exit code $LASTEXITCODE."
    }
}

if (-not (Test-IsAdministrator)) {
    throw "This script must be run from an elevated PowerShell session."
}

$resolvedPackageRoot = Resolve-PackageRoot -Value $PackageRoot
$resolvedInstallDir = [System.IO.Path]::GetFullPath($InstallDir)
$resolvedDataDir = [System.IO.Path]::GetFullPath($DataDir)
$indexDir = Join-Path $resolvedDataDir "index"
$logsDir = Join-Path $resolvedDataDir "logs"
$runDir = Join-Path $resolvedDataDir "run"

$sfisExe = Resolve-SourceFile -Root $resolvedPackageRoot -Name "sfis.exe" -RelativePaths @(
    "bin\sfis.exe",
    "build\ARM64\Release\sfis.exe",
    "build\x64\Release\sfis.exe",
    "build\Release\sfis.exe"
)
$sfisctlExe = Resolve-SourceFile -Root $resolvedPackageRoot -Name "sfisctl.exe" -RelativePaths @(
    "bin\sfisctl.exe",
    "build\ARM64\Release\sfisctl.exe",
    "build\x64\Release\sfisctl.exe",
    "build\Release\sfisctl.exe"
)

$service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($null -ne $service -and $service.Status -ne "Stopped") {
    Invoke-Sc -Arguments @("stop", $ServiceName)
    $service.WaitForStatus("Stopped", [TimeSpan]::FromSeconds(30))
}

New-Item -ItemType Directory -Force -Path `
    $resolvedInstallDir, $resolvedDataDir, $indexDir, $logsDir, $runDir |
    Out-Null

if ($ResetIndex) {
    $indexPath = Join-Path $indexDir "sfis-index-v1.bin"
    if (Test-Path -LiteralPath $indexPath) {
        Remove-Item -LiteralPath $indexPath -Force
    }
}

Copy-Item -LiteralPath $sfisExe -Destination (Join-Path $resolvedInstallDir "sfis.exe") -Force
Copy-Item -LiteralPath $sfisctlExe -Destination (Join-Path $resolvedInstallDir "sfisctl.exe") -Force

$monitorSource = Join-Path $resolvedPackageRoot "bin\SFIS.Monitor"
if (Test-Path -LiteralPath $monitorSource -PathType Container) {
    $monitorDest = Join-Path $resolvedInstallDir "SFIS.Monitor"
    if (Test-Path -LiteralPath $monitorDest) {
        Remove-Item -LiteralPath $monitorDest -Recurse -Force
    }
    Copy-Item -LiteralPath $monitorSource -Destination $monitorDest -Recurse -Force

    if ($CreateMonitorShortcut) {
        $startMenuDir = Join-Path $env:ProgramData "Microsoft\Windows\Start Menu\Programs\SFIS"
        New-Item -ItemType Directory -Force -Path $startMenuDir | Out-Null
        $shortcutPath = Join-Path $startMenuDir "SFIS Monitor.lnk"
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = Join-Path $monitorDest "SFIS.Monitor.exe"
        $shortcut.WorkingDirectory = $monitorDest
        $shortcut.Description = "SFIS Monitor"
        $shortcut.Save()
    }
}

foreach ($name in @("README.md", "LICENSE", "LICENSE.txt")) {
    $source = Join-Path $resolvedPackageRoot $name
    if (Test-Path -LiteralPath $source -PathType Leaf) {
        Copy-Item -LiteralPath $source -Destination (Join-Path $resolvedInstallDir $name) -Force
    }
}

$docsSource = Join-Path $resolvedPackageRoot "docs"
if (Test-Path -LiteralPath $docsSource -PathType Container) {
    $docsDest = Join-Path $resolvedInstallDir "docs"
    if (Test-Path -LiteralPath $docsDest) {
        Remove-Item -LiteralPath $docsDest -Recurse -Force
    }
    Copy-Item -LiteralPath $docsSource -Destination $docsDest -Recurse -Force
}

$serviceInstallScript = Join-Path $PSScriptRoot "install-sfis-service.ps1"
if (-not (Test-Path -LiteralPath $serviceInstallScript -PathType Leaf)) {
    $serviceInstallScript = Join-Path $resolvedPackageRoot "scripts\install-sfis-service.ps1"
}
if (-not (Test-Path -LiteralPath $serviceInstallScript -PathType Leaf)) {
    throw "install-sfis-service.ps1 was not found."
}

& $serviceInstallScript `
    -SfisExePath (Join-Path $resolvedInstallDir "sfis.exe") `
    -ServiceName $ServiceName `
    -DisplayName $DisplayName `
    -PipeName "sfis"

if (-not $NoStart) {
    Invoke-Sc -Arguments @("start", $ServiceName)
}

if ($Verify) {
    Start-Sleep -Seconds 2
    & (Join-Path $resolvedInstallDir "sfisctl.exe") status
    if ($LASTEXITCODE -ne 0) {
        throw "sfisctl status verification failed with exit code $LASTEXITCODE."
    }
}

Write-Host "Installed SFIS."
Write-Host "InstallDir: $resolvedInstallDir"
Write-Host "DataDir: $resolvedDataDir"
Write-Host "ServiceName: $ServiceName"
Write-Host "Monitor: $(Join-Path $resolvedInstallDir "SFIS.Monitor\SFIS.Monitor.exe")"
