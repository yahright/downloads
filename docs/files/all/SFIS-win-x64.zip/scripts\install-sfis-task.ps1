[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string]$SfisExePath,

    [string]$TaskName = "SFIS"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdministrator)) {
    throw "This script must be run from an elevated PowerShell session."
}

if ([string]::IsNullOrWhiteSpace($SfisExePath)) {
    $repoRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "..")).ProviderPath
    $SfisExePath = Join-Path $repoRoot "build\Release\sfis.exe"
}

try {
    $resolvedExePath = (Resolve-Path -LiteralPath $SfisExePath).ProviderPath
}
catch {
    throw "sfis.exe was not found: $SfisExePath"
}

if (-not (Test-Path -LiteralPath $resolvedExePath -PathType Leaf)) {
    throw "sfis.exe path is not a file: $resolvedExePath"
}

$workingDirectory = [System.IO.Path]::GetDirectoryName($resolvedExePath)
$currentUser = [Security.Principal.WindowsIdentity]::GetCurrent().Name

$action = New-ScheduledTaskAction `
    -Execute $resolvedExePath `
    -WorkingDirectory $workingDirectory

$trigger = New-ScheduledTaskTrigger -AtLogOn -User $currentUser
$principal = New-ScheduledTaskPrincipal `
    -UserId $currentUser `
    -LogonType Interactive `
    -RunLevel Highest

$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -ExecutionTimeLimit ([TimeSpan]::Zero)

$task = New-ScheduledTask `
    -Action $action `
    -Trigger $trigger `
    -Principal $principal `
    -Settings $settings `
    -Description "Starts SFIS at user logon with highest privileges."

Register-ScheduledTask `
    -TaskName $TaskName `
    -InputObject $task `
    -Force | Out-Null

Write-Host "Registered scheduled task '$TaskName'."
Write-Host "Executable: $resolvedExePath"
Write-Host "WorkingDirectory: $workingDirectory"
Write-Host "User: $currentUser"
