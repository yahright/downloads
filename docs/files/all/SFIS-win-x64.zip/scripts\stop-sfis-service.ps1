[CmdletBinding()]
param(
    [string]$ServiceName = "SFIS"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Stop-Service -Name $ServiceName
$service = Get-Service -Name $ServiceName
$service.WaitForStatus("Stopped", [TimeSpan]::FromMinutes(2))
Get-Service -Name $ServiceName
