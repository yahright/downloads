[CmdletBinding()]
param(
    [string]$ServiceName = "SFIS"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($null -eq $service) {
    Write-Host "Service '$ServiceName' is not installed."
    return
}

if ($service.Status -ne "Stopped") {
    & sc.exe stop $ServiceName
    if ($LASTEXITCODE -ne 0) {
        throw "sc.exe stop $ServiceName failed with exit code $LASTEXITCODE."
    }
    $service.WaitForStatus("Stopped", [TimeSpan]::FromSeconds(30))
}

& sc.exe delete $ServiceName
if ($LASTEXITCODE -ne 0) {
    throw "sc.exe delete $ServiceName failed with exit code $LASTEXITCODE."
}

Write-Host "Uninstalled service '$ServiceName'."
