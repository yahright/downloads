@echo off
setlocal
cd /d "%~dp0"
start "" "Scopy.Gui.exe"
