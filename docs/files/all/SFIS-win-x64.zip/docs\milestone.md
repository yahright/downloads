SFIS Roadmap (Everything-class Filesystem Service)

Vision

SFIS =
Cross-platform filesystem indexing/search substrate
NOT:
  search UI app
BUT:
  low-level filesystem service
  reusable backend
  IPC platform

対象：

Windows
macOS
(Linux optional later)

UIは持たない。

利用先：

InsightFlow
Sgrep
QuickNav
AI indexing
DiskUsage
duplicate finder
future tools

⸻

Guiding Principles

1. Backend abstraction first

Windows 固有実装を core に漏らさない。

core/
platform/windows/
platform/macos/

を徹底。

⸻

2. Capability-based design

NTFSならOK

ではなく：

supports_mft
supports_journal
supports_recursive_scan
supports_watch
supports_fast_size

で扱う。

⸻

3. Tiered backend

Tier 1

journaled filesystem

最速。

Windows:

NTFS + MFT + USN

macOS:

APFS + FSEvents

⸻

Tier 2

recursive scan + watcher

汎用fallback。

⸻

Tier 3

snapshot/manual refresh

NAS/cloud/rclone。

⸻

4. IPC-first

SFIS は library ではなく：

filesystem daemon/service

として設計。

⸻

Milestones

M0 — Current State ✅

Goal

Windows NTFS indexing prototype。

Status

MFT scan
USN watch
binary IPC v2
ListFiles
Search
GetFolderSize
C# SDK
InsightFlow integration

⸻

M1 — Foundation Stabilization

Goal

「壊れない backend」。

Tasks

Volume Capability Matrix

supports_mft
supports_usn
supports_watch
filesystem_type
is_virtual
is_network

⸻

Graceful Fallback

USN unavailable
↓
skip or fallback

⸻

Error Handling

UTF-8 errors
structured errors
per-volume isolation

⸻

Config System

include/exclude volumes
scan policy
watch policy

⸻

Diagnostics

status
backend info
capability dump
performance stats

⸻

Deliverable

stable Windows backend

⸻

M2 — Persistent Index Database

Goal

Everything-class persistence。

Tasks

SQLite backend

Tables:

files
directories
frn graph
volumes
metadata

⸻

Startup Recovery

journal replay
dirty shutdown recovery
incremental rebuild

⸻

Snapshot Serialization

fast startup

⸻

Memory Reduction

DB-backed path reconstruction

⸻

Deliverable

persistent index service
fast restart

⸻

M3 — Query Engine

Goal

Everything-class search syntax。

Tasks

Query Parser / AST

foo
foo bar
ext:cs
size:>1mb
modified:<7d
path:src
regex:

⸻

Boolean

AND
OR
NOT
()

⸻

Fast Incremental Query

typed query refinement

⸻

Sort Engine

name
size
date
path
extension

⸻

Deliverable

full query engine

⸻

M4 — Reactive IPC

Goal

Live query subscriptions。

Tasks

SubscribeQuery

query subscription
incremental updates

⸻

Delta Events

added
removed
updated
renamed

⸻

Streaming Protocol

binary chunk streaming

⸻

Multi-client support

many clients
shared backend

⸻

Deliverable

real-time search platform

⸻

M5 — Windows Service

Goal

Production Windows daemon。

Tasks

Service Mode

SYSTEM/admin service

⸻

User Client

normal user IPC

⸻

Auto-start

boot start
delayed start
recovery

⸻

ACL / Security

pipe ACL
client auth

⸻

Deliverable

Everything-style service architecture

⸻

M6 — Multi-backend Support

Goal

Non-NTFS support。

Tasks

Recursive Backend

recursive scan
watcher

⸻

Snapshot Backend

manual refresh

⸻

Network Share Support

UNC
NAS
SMB

⸻

Cloud-aware backend

optional later:

Dropbox
Google Drive
OneDrive

⸻

Deliverable

filesystem-independent service

⸻

M7 — macOS Backend

Goal

Native APFS support。

Tasks

APFS Enumerator

⸻

FSEvents watcher

⸻

Spotlight interoperability

optional

⸻

launchd daemon

⸻

Unix Domain Socket IPC

⸻

Deliverable

native macOS SFIS backend

⸻

M8 — Advanced Metadata

Goal

Beyond filename search。

Tasks

Property Indexing

size
dates
attributes
tags
git status

⸻

Duplicate Detection

hash index

⸻

Content Index Hook

optional:

grep bridge
text extraction

⸻

Deliverable

filesystem intelligence layer

⸻

M9 — Ecosystem Integration

Goal

Filesystem platform。

Targets

InsightFlow

search
diskusage
batch ops
sync

⸻

Sgrep

candidate narrowing
incremental grep

⸻

AI indexing

embedding pipeline
semantic cache

⸻

SDK

C#
C++
Rust
Python

⸻

Non-Goals

SFIS will NOT become:

Explorer replacement
GUI search app
file manager

⸻

Core Identity

Everything:
  Search application
SFIS:
  Cross-platform filesystem indexing platform