[CmdletBinding()]
param(
    [string]$InstallDir = "$env:ProgramFiles\SFIS",
    [string]$DataDir = "$env:ProgramData\SFIS",
    [string]$ServiceName = "SFIS",
    [switch]$PurgeData
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Assert-SafeDirectoryTarget {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$ExpectedLeaf
    )

    $fullPath = [System.IO.Path]::GetFullPath($Path)
    $leaf = Split-Path -Leaf $fullPath
    if ([string]::IsNullOrWhiteSpace($fullPath) -or $leaf -ne $ExpectedLeaf) {
        throw "Refusing to remove unexpected path '$fullPath'."
    }
    return $fullPath
}

if (-not (Test-IsAdministrator)) {
    throw "This script must be run from an elevated PowerShell session."
}

$serviceUninstallScript = Join-Path $PSScriptRoot "uninstall-sfis-service.ps1"
if (Test-Path -LiteralPath $serviceUninstallScript -PathType Leaf) {
    & $serviceUninstallScript -ServiceName $ServiceName
}
else {
    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($null -ne $service) {
        if ($service.Status -ne "Stopped") {
            & sc.exe stop $ServiceName
            if ($LASTEXITCODE -ne 0) {
                throw "sc.exe stop $ServiceName failed with exit code $LASTEXITCODE."
            }
            $service.WaitForStatus("Stopped", [TimeSpan]::FromSeconds(30))
        }

        & sc.exe delete $ServiceName
        if ($LASTEXITCODE -ne 0) {
            throw "sc.exe delete $ServiceName failed with exit code $LASTEXITCODE."
        }
    }
}

$resolvedInstallDir = Assert-SafeDirectoryTarget -Path $InstallDir -ExpectedLeaf "SFIS"
$shortcutPath = Join-Path $env:ProgramData "Microsoft\Windows\Start Menu\Programs\SFIS\SFIS Monitor.lnk"
if (Test-Path -LiteralPath $shortcutPath -PathType Leaf) {
    Remove-Item -LiteralPath $shortcutPath -Force
    Write-Host "Removed Monitor shortcut: $shortcutPath"
}

if (Test-Path -LiteralPath $resolvedInstallDir) {
    if ($PurgeData) {
        Remove-Item -LiteralPath $resolvedInstallDir -Recurse -Force
        Write-Host "Removed install directory: $resolvedInstallDir"
    }
    else {
        $logsPath = Join-Path $resolvedInstallDir "logs"
        Get-ChildItem -LiteralPath $resolvedInstallDir -Force |
            Where-Object { $_.FullName -ne $logsPath } |
            Remove-Item -Recurse -Force
        Write-Host "Removed install files and preserved logs: $logsPath"
    }
}
else {
    Write-Host "Install directory not found: $resolvedInstallDir"
}

if ($PurgeData) {
    $resolvedDataDir = Assert-SafeDirectoryTarget -Path $DataDir -ExpectedLeaf "SFIS"
    if (Test-Path -LiteralPath $resolvedDataDir) {
        Remove-Item -LiteralPath $resolvedDataDir -Recurse -Force
        Write-Host "Purged data directory: $resolvedDataDir"
    }
    else {
        Write-Host "Data directory not found: $resolvedDataDir"
    }
}
else {
    Write-Host "Preserved data directory: $([System.IO.Path]::GetFullPath($DataDir))"
}

Write-Host "Uninstalled SFIS."
