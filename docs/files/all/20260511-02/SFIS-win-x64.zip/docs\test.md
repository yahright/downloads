# SFIS Test Notes

This document lists the current stabilization tests for the M6/M7 substrate
work. These tests complement unit tests and native self-tests by exercising the
real process, named pipe server, and C# SDK where possible.

## Core Checks

Run C# tests:

```powershell
dotnet test SFIS.sln --configuration Release
```

Run native self-tests after building `sfis.exe`:

```powershell
.\build\ARM64\Release\sfis.exe --store-self-test
.\build\ARM64\Release\sfis.exe --paths-self-test
.\build\ARM64\Release\sfis.exe --metadata-self-test
.\build\ARM64\Release\sfis.exe --query-self-test
.\build\ARM64\Release\sfis.exe --recursive-self-test
```

## Smoke Test Summary

| Test | Script | Required | Purpose |
| --- | --- | --- | --- |
| Persistent mount restart | `scripts/test-persistent-mount.ps1` | Yes for local stabilization | Verifies Persistent mount config survives real `sfis.exe` restart. |
| Reactive events | `scripts/test-reactive-events.ps1` | Yes for local stabilization | Verifies mount lifecycle, refresh, invalidation, unmount, and unsubscribe events through the real pipe and SDK. |
| SFIS Monitor dev run | `scripts/run-monitor-dev.ps1` | Manual UI smoke only | Starts a real `sfis.exe` daemon with isolated state, then launches `SFIS.Monitor` against that daemon. |
| Windows install smoke | `scripts/install-sfis.ps1 -Verify` | Manual elevated smoke only | Installs the Program Files/ProgramData layout, registers the Windows Service, starts it, and verifies `sfisctl status`. |
| macOS install smoke | `scripts/install-sfis-macos.sh --verify` | Manual macOS smoke only | Installs the user Application Support layout, registers the user LaunchAgent, starts it, and verifies `sfisctl status`. |
| Optional NTFS watch events | `scripts/test-watch-events.ps1` | No | Verifies NTFS USN watcher invalidation when the environment supports it; skips cleanly otherwise. |

Windows smoke scripts use a unique pipe name and isolated temporary state. They
do not require installing the Windows service. macOS smoke checks use the Unix
socket selected by `SFIS_SOCKET_PATH` or the default
`~/Library/Application Support/SFIS/run/sfis.sock`.

## SFIS Monitor Dev Run

Run on Windows after building `sfis.exe`:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/run-monitor-dev.ps1
```

The script creates a unique named pipe, temporary index path, and temporary
mount config path, starts `sfis.exe` with `--allow-multiple`, `--pipe-name`,
and `--index-path`, waits for the daemon to become ready, sets
`SFIS_PIPE_NAME` for the child process, and launches:

```powershell
dotnet run --project SFIS.Monitor/SFIS.Monitor.csproj
```

When the Monitor process exits, the script stops the daemon and removes the
temporary files. Use `-KeepTemp` to keep the isolated state and daemon logs for
debugging.

Manual smoke checklist:

- The top connection banner shows connected/disconnected state, endpoint kind
  and address, server version, reactive IPC availability, and the last
  operation error when one exists.
- During Connect, Refresh All, mount operations, config operations, and event
  subscribe/unsubscribe, the top bar shows a busy operation name and disables
  conflicting buttons.
- Monitor starts and reaches `connected`.
- Status tab shows server version, protocol capabilities, log path, endpoint,
  and mount config summary fields.
- `Refresh All` updates status, mounts, and mount configs together.
- Volumes tab shows volume capability/status rows.
- Mounts tab shows current mounts after daemon startup or after adding the
  smoke mount below.
- Refresh, mount, config, and subscribe buttons are disabled while
  disconnected; selected-mount actions are disabled until a mount is selected;
  selected-config actions are disabled until a config is selected.
- Add mount can add a temporary folder as a recursive Ephemeral mount. In the
  Mounts tab, enter a temp folder path, `recursive` for backend, and
  `Ephemeral` for policy, then click `Add mount`.
- `Refresh selected mount` works for the selected mount.
- Events tab can `Subscribe`.
- Triggering `Refresh selected mount` while subscribed shows
  `MountStatusChanged`, `MountRefreshed`, and `MountInvalidated`.
- `Clear events` clears the retained event list.
- `Unmount selected mount` shows `MountRemoved`.
- Mount Configs tab is visible and refreshable. The recursive Ephemeral smoke
  mount should not persist as a config.

Known manual-smoke notes:

- Reactive events are live hints, not durable history. Subscribe before
  triggering refresh or unmount actions.
- The top bar displays connection/operation errors. Mount-specific action
  buttons are disabled until a mount is selected.

## Windows Install Smoke

Run from an elevated PowerShell session after creating or unpacking a Windows
zip package:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install-sfis.ps1 -Verify
.\build\ARM64\Release\sfisctl.exe status
powershell -ExecutionPolicy Bypass -File .\scripts\uninstall-sfis.ps1
```

The install script copies binaries to `C:\Program Files\SFIS`, creates
`C:\Program Files\SFIS\logs` and `C:\ProgramData\SFIS`, registers the `SFIS`
Windows Service with `--log-path "C:\Program Files\SFIS\logs\sfis.log"`, and
preserves logs/data during uninstall unless `-PurgeData` is supplied.

Connection debugging checklist:

```powershell
Get-Service SFIS
Get-Content "C:\Program Files\SFIS\logs\sfis.log" -Tail 100
Get-Content "C:\ProgramData\SFIS\logs\sfis.log" -Tail 100
.\sfisctl.exe status
```

## macOS Install Smoke

Run on macOS after creating the zip package:

```bash
./build-macos-zip.sh
unzip dist/SFIS-macos-arm64.zip -d /tmp/sfis-package
cd /tmp/sfis-package/SFIS-macos-arm64
./scripts/install-sfis-macos.sh --verify
./bin/sfisctl status
./scripts/status-sfis-macos.sh
./scripts/uninstall-sfis-macos.sh
```

The install script copies binaries to
`~/Library/Application Support/SFIS/bin`, creates `index`, `logs`, and `run`,
writes `~/Library/LaunchAgents/com.sfis.daemon.plist` with
`--log-path ~/Library/Application Support/SFIS/logs/sfis.log`, and starts the
user-level LaunchAgent. It preserves `mounts.json`, logs, and the index by
default; use `--reset-index` during install or `--purge-data` during uninstall
for explicit data removal. The default socket is
`~/Library/Application Support/SFIS/run/sfis.sock`.

Connection debugging checklist:

```bash
launchctl print "gui/$UID/com.sfis.daemon"
tail -100 "$HOME/Library/Application Support/SFIS/logs/sfis.log"
sfisctl status
```

## macOS Recursive Daemon Smoke Plan

Run after building the POSIX recursive-only daemon and `sfisctl` on macOS. The
full M7 compile/smoke runbook is maintained in [macOS plan](macos-plan.md).

```bash
export SFIS_SOCKET_PATH="$HOME/Library/Application Support/SFIS/run/sfis.sock"
./sfis --socket-path "$SFIS_SOCKET_PATH"
```

In another shell:

```bash
./sfisctl --socket-path "$SFIS_SOCKET_PATH" status
dotnet run --project SFIS.TestApp/SFIS.TestApp.csproj -- status
dotnet run --project SFIS.Monitor/SFIS.Monitor.csproj
```

Manual macOS checklist:

- `sfisctl status` completes the Unix socket Hello handshake.
- C# SDK `status` reaches the same daemon through `SFIS_SOCKET_PATH`.
- Monitor shows `UnixSocket` and the socket path in the connection banner.
- Add a readable temp folder as a recursive mount.
- `Refresh selected mount`, `Search`, and `ListFiles` return updated results
  after create/delete/rename and explicit refresh.

## Persistent Mount Restart Smoke Test

Run on Windows after building `sfis.exe`:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/test-persistent-mount.ps1
```

The script starts a real `sfis.exe`, creates a temporary recursive Persistent
mount through `SFIS.TestApp`, sets a refresh interval, stops and restarts the
process, then verifies `status`, `list-mounts`, and `mount-configs`.

The test is isolated from the machine-wide config by setting
`SFIS_MOUNT_CONFIG_PATH` to a temporary `mounts.json`.

## Reactive Event Smoke Test

Run on Windows after building `sfis.exe`:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/test-reactive-events.ps1
```

The script uses a unique named pipe, a temporary index file, and a temporary
`SFIS_MOUNT_CONFIG_PATH`, then runs `SFIS.TestApp event-smoke <temp-root>`
through the C# SDK against the real `sfis.exe` pipe server.

The smoke test verifies:

- `event_id` values are monotonic for the consumed event stream.
- The observed lifecycle events match the created `mount_id`.
- Initial `MountInvalidated` carries `generation > 0`.
- Refresh `MountInvalidated` carries a generation greater than the initial
  generation.
- No `MountFailed` event is observed for the smoke mount.
- The SDK event reader is stopped cleanly after `Unsubscribe`.

Reactive events are live invalidation hints, not a durable event log. Clients
must query current state after reconnects or errors; this test intentionally
does not cover durable replay, reconnect history, file-level delta events, or
automatic reconnect.

## Optional NTFS Watch Event Smoke Test

Run on Windows after building `sfis.exe`:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/test-watch-events.ps1
```

This is an optional local smoke test for the reliable NTFS USN watcher backend.
It requires a local fixed NTFS drive, an available USN journal, and permission
for `sfis.exe` to open the volume. The script uses a unique pipe name, isolated
index/config paths, includes only the temporary directory's drive, and runs
`SFIS.TestApp watch-event-smoke <temp-root>`.

The smoke test verifies:

- `event_id` values are monotonic for consumed events.
- The target root is covered by a realtime `ntfs-usn` mount.
- Creating a temp file produces `MountInvalidated` with `trigger = "Watch"`.
- The invalidation reason contains `usn`.
- `changed_file_estimate > 0`.
- The mount generation increases from the initial value.
- `ListFiles` eventually sees the created file.

If the environment does not support the watcher path, the command prints
`SKIPPED: NTFS USN watcher not available` and exits successfully. This test is
not a CI requirement and does not validate file-level delta delivery, durable
replay, reconnect behavior, network watchers, or debounce tuning.
