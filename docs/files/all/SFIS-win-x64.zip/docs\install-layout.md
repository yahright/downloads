# SFIS Install Layout and Packaging Plan

This document fixes the first production-oriented install boundary for SFIS as
a service substrate. Development overrides remain available, but installed
defaults should be predictable.

## Product Split

SFIS Core is the long-running service. It owns indexing, persistent mount
configuration, snapshots, and IPC.

SFIS Monitor is a separate management GUI client. It connects to the service
through the default endpoint and does not own service state.

## Windows Layout

Program files:

```text
C:\Program Files\SFIS\
  sfis.exe
  sfisctl.exe
  SFIS.Monitor\
    SFIS.Monitor.exe
    ...
  README.md
  docs\
    ...
```

Persistent state:

```text
C:\ProgramData\SFIS\
  index\
    sfis-index-v1.bin
  mounts.json
  logs\
    sfis.log
  run\
```

Default IPC endpoint:

```text
\\.\pipe\sfis
```

`SFIS_PIPE_NAME` remains available for development and isolated tests. Formal
service installs should use the default `sfis` pipe.

## Windows Service

Service name:

```text
SFIS
```

Display name:

```text
SFIS Filesystem Indexing Service
```

Startup:

```text
Automatic
```

Run account:

- Initial: `LocalSystem`
- Future: configurable service account

Scheduled Task registration remains a development/compatibility path. The
formal install path is Windows Service.

## Windows Installer Strategy

Phase 1 uses a zip plus PowerShell scripts. Phase 2 can move to WiX/MSI after
the service layout and upgrade behavior are stable. MSIX is not the preferred
service packaging route for the current substrate model.

Release artifact:

```text
SFIS-win-arm64.zip
  bin\
    sfis.exe
    sfisctl.exe
    SFIS.Monitor\
      ...
  scripts\
    install-sfis.ps1
    uninstall-sfis.ps1
    start-sfis-service.ps1
    stop-sfis-service.ps1
    install-sfis-service.ps1
    uninstall-sfis-service.ps1
  docs\
    ...
  README.md
```

## Install Behavior

`install-sfis.ps1` should:

1. Require an elevated PowerShell session.
2. Stop the existing `SFIS` service if it is running.
3. Create `C:\Program Files\SFIS`.
4. Copy `sfis.exe`, `sfisctl.exe`, Monitor files, docs, and README.
5. Create `C:\ProgramData\SFIS\index`.
6. Create `C:\ProgramData\SFIS\logs`.
7. Preserve `C:\ProgramData\SFIS\mounts.json`.
8. Preserve the index snapshot unless `-ResetIndex` is supplied.
9. Register or update the Windows Service.
10. Start the service unless `-NoStart` is supplied.
11. Optionally verify `sfisctl status`.

`install-sfis.ps1 -CreateMonitorShortcut` also creates a Start Menu shortcut
for SFIS Monitor. Monitor can always be launched directly:

```text
C:\Program Files\SFIS\SFIS.Monitor\SFIS.Monitor.exe
```

## Uninstall Behavior

`uninstall-sfis.ps1` should:

1. Require an elevated PowerShell session.
2. Stop the `SFIS` service.
3. Unregister the service.
4. Remove `C:\Program Files\SFIS`.
5. Preserve `C:\ProgramData\SFIS` by default.
6. Remove `C:\ProgramData\SFIS` only with `-PurgeData`.

## Upgrade Behavior

Upgrade preserves:

- `mounts.json`
- index snapshot
- logs unless independently rotated
- service name
- default pipe name

Upgrade may replace:

- service binaries
- Monitor binaries
- scripts
- docs

## macOS User-Level Layout

M0/M1 uses a user-level install so SFIS runs in the same user context as
InsightFlow and does not require `sudo`.

```text
~/Library/Application Support/SFIS/
  bin/
    sfis
    sfisctl
  SFIS.Monitor/
    SFIS.Monitor
    ...
  index/
    sfis-index-v1.bin
  mounts.json
  logs/
    sfis.out.log
    sfis.err.log
  run/
    sfis.sock
```

Default IPC endpoint:

```text
~/Library/Application Support/SFIS/run/sfis.sock
```

`SFIS_SOCKET_PATH` remains available for development, isolated tests, and
non-default installs.

User LaunchAgent:

```text
~/Library/LaunchAgents/com.sfis.daemon.plist
```

The LaunchAgent sets `SFIS_INDEX_PATH`, `SFIS_MOUNT_CONFIG_PATH`, and
`SFIS_SOCKET_PATH`, runs at load, keeps the daemon alive, and writes stdout and
stderr to `logs/sfis.out.log` and `logs/sfis.err.log`.

Release artifact:

```text
SFIS-macos-arm64.zip
  bin/
    sfis
    sfisctl
  SFIS.Monitor/
    SFIS.Monitor
    ...
  scripts/
    install-sfis-macos.sh
    uninstall-sfis-macos.sh
    run-sfis-monitor-macos.sh
    start-sfis-macos.sh
    stop-sfis-macos.sh
    status-sfis-macos.sh
  docs/
    README.md
    ...
```

`install-sfis-macos.sh` creates the Application Support directories, copies
the binaries and Monitor directory, preserves `mounts.json`, preserves the
index unless `--reset-index` is supplied, writes the LaunchAgent plist, starts
the LaunchAgent unless `--no-start` is supplied, and can verify with
`--verify`.

`uninstall-sfis-macos.sh` unloads the LaunchAgent, removes the plist and
installed binaries and Monitor directory, and preserves Application Support data unless
`--purge-data` is supplied.

The macOS Monitor is packaged as an unsigned framework-dependent publish
directory for now, not a signed `.app`. Launch it from Terminal:

```bash
./scripts/run-sfis-monitor-macos.sh
```

Future packaging can wrap this into a signed and notarized `.app`.

Future system-level layout remains reserved for `/Library/Application Support`
and `/Library/LaunchDaemons/com.sfis.daemon.plist`.

## Install Smoke

Windows Phase 1 smoke:

```powershell
.\scripts\install-sfis.ps1 -Verify
.\build\ARM64\Release\sfisctl.exe status
dotnet run --project SFIS.Monitor/SFIS.Monitor.csproj
.\scripts\uninstall-sfis.ps1
```

Expected:

- service installs and starts
- `sfisctl status` connects to `\\.\pipe\sfis`
- Monitor connects to `NamedPipe: sfis`
- uninstall removes binaries and preserves ProgramData

macOS Phase 1 smoke:

```bash
./build-macos-zip.sh
unzip dist/SFIS-macos-arm64.zip -d /tmp/sfis-package
cd /tmp/sfis-package/SFIS-macos-arm64
./scripts/install-sfis-macos.sh --verify
./bin/sfisctl status
./scripts/status-sfis-macos.sh
./scripts/run-sfis-monitor-macos.sh
./scripts/uninstall-sfis-macos.sh
```

Expected:

- LaunchAgent installs and starts for the current user
- `sfisctl status` connects to
  `~/Library/Application Support/SFIS/run/sfis.sock`
- Monitor launches from the installed Application Support directory
- uninstall removes binaries and preserves Application Support state

## Non-Goals

- WiX MSI
- MSIX
- code signing
- auto-update
- macOS signed installer
- macOS notarization
- Homebrew formula
- system-level macOS LaunchDaemon
- service account UI
- ProgramData ACL hardening beyond the current baseline
