[CmdletBinding()]
param(
    [string]$ServiceName = "SFIS"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Start-Service -Name $ServiceName
$service = Get-Service -Name $ServiceName
$service.WaitForStatus("Running", [TimeSpan]::FromMinutes(10))
Get-Service -Name $ServiceName
