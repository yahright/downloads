param(
    [string]$SfisExe = "",
    [string]$MonitorProject = "",
    [string]$Configuration = "Debug",
    [int]$ReadyTimeoutSeconds = 120,
    [switch]$KeepTemp
)

$ErrorActionPreference = "Stop"

function Resolve-RepoRoot {
    return (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
}

function Quote-Arg([string]$Value) {
    return '"' + ($Value -replace '"', '\"') + '"'
}

function New-SfisProcess(
    [string]$PipeName,
    [string]$IndexPath,
    [string]$MountConfigPath,
    [string]$StdOutPath,
    [string]$StdErrPath) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $script:SfisExe
    $quotedArgs = @(
        "--allow-multiple",
        "--pipe-name", $PipeName,
        "--index-path", $IndexPath
    ) | ForEach-Object { Quote-Arg $_ }
    $psi.Arguments = $quotedArgs -join " "
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.Environment["SFIS_MOUNT_CONFIG_PATH"] = $MountConfigPath

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi
    $script:SfisEventSubscriptions += Register-ObjectEvent -InputObject $process -EventName OutputDataReceived -Action {
        if ($EventArgs.Data -ne $null) {
            Add-Content -LiteralPath $Event.MessageData.StdOut -Value $EventArgs.Data
        }
    } -MessageData @{ StdOut = $StdOutPath }
    $script:SfisEventSubscriptions += Register-ObjectEvent -InputObject $process -EventName ErrorDataReceived -Action {
        if ($EventArgs.Data -ne $null) {
            Add-Content -LiteralPath $Event.MessageData.StdErr -Value $EventArgs.Data
        }
    } -MessageData @{ StdErr = $StdErrPath }

    if (-not $process.Start()) {
        throw "failed to start sfis.exe"
    }

    $process.BeginOutputReadLine()
    $process.BeginErrorReadLine()

    return $process
}

function Stop-SfisProcess($Process) {
    if ($null -eq $Process) {
        return
    }

    if (-not $Process.HasExited) {
        Stop-Process -Id $Process.Id -Force -ErrorAction SilentlyContinue
        $Process.WaitForExit(5000) | Out-Null
    }
}

function Wait-ForSfisReady($Process, [string]$StdOutPath, [string]$StdErrPath, [int]$TimeoutSeconds) {
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        if ($Process.HasExited) {
            $stdout = if (Test-Path -LiteralPath $StdOutPath) { Get-Content -LiteralPath $StdOutPath -Raw } else { "" }
            $stderr = if (Test-Path -LiteralPath $StdErrPath) { Get-Content -LiteralPath $StdErrPath -Raw } else { "" }
            throw "sfis.exe exited before becoming ready. exit=$($Process.ExitCode)`nstdout:`n$stdout`nstderr:`n$stderr"
        }

        if ((Test-Path -LiteralPath $StdOutPath) -and
            ((Get-Content -LiteralPath $StdOutPath -Raw) -match "SFIS ready\.")) {
            return
        }

        Start-Sleep -Milliseconds 500
    }

    throw "sfis.exe did not become ready within $TimeoutSeconds seconds. Logs: $StdOutPath $StdErrPath"
}

$repoRoot = Resolve-RepoRoot
if ([string]::IsNullOrWhiteSpace($SfisExe)) {
    $SfisExe = Join-Path $repoRoot "build\ARM64\Release\sfis.exe"
}
if ([string]::IsNullOrWhiteSpace($MonitorProject)) {
    $MonitorProject = Join-Path $repoRoot "SFIS.Monitor\SFIS.Monitor.csproj"
}

$script:SfisExe = (Resolve-Path $SfisExe).Path
$MonitorProject = (Resolve-Path $MonitorProject).Path
$pipeName = "sfis-monitor-dev-$PID-$([Guid]::NewGuid().ToString('N').Substring(0, 8))"
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) "sfis-monitor-dev-$PID-$([Guid]::NewGuid().ToString('N'))"
$indexPath = Join-Path $tempRoot "index\sfis-index-v1.bin"
$mountConfigPath = Join-Path $tempRoot "programdata\SFIS\mounts.json"
$stdout = Join-Path $tempRoot "sfis.out.log"
$stderr = Join-Path $tempRoot "sfis.err.log"
$process = $null
$oldPipeName = $env:SFIS_PIPE_NAME
$script:SfisEventSubscriptions = @()

try {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $indexPath) | Out-Null
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $mountConfigPath) | Out-Null

    Write-Host "[monitor-dev] temp=$tempRoot"
    Write-Host "[monitor-dev] pipe=$pipeName"
    Write-Host "[monitor-dev] index=$indexPath"
    Write-Host "[monitor-dev] mount_config=$mountConfigPath"

    $process = New-SfisProcess $pipeName $indexPath $mountConfigPath $stdout $stderr
    Wait-ForSfisReady $process $stdout $stderr $ReadyTimeoutSeconds

    $env:SFIS_PIPE_NAME = $pipeName
    Write-Host "[monitor-dev] starting SFIS.Monitor"
    & dotnet run --project $MonitorProject --configuration $Configuration
    if ($LASTEXITCODE -ne 0) {
        throw "SFIS.Monitor exited with code $LASTEXITCODE"
    }
} finally {
    $env:SFIS_PIPE_NAME = $oldPipeName
    Stop-SfisProcess $process
    foreach ($subscription in $script:SfisEventSubscriptions) {
        Unregister-Event -SubscriptionId $subscription.Id -ErrorAction SilentlyContinue
        Remove-Job -Id $subscription.Id -Force -ErrorAction SilentlyContinue
    }
    if (-not $KeepTemp) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    } else {
        Write-Host "[monitor-dev] kept temp=$tempRoot"
        Write-Host "[monitor-dev] sfis stdout=$stdout"
        Write-Host "[monitor-dev] sfis stderr=$stderr"
    }
}
