# SFIS macOS M0 Plan

This document defines the first macOS validation boundary for SFIS. The goal is
not a full macOS backend. The goal is to prove that SFIS can run as a
cross-platform indexing substrate with recursive mounts, explicit refresh, and
portable IPC.

## Minimum macOS Substrate

The first useful macOS target is:

- `sfis` daemon starts on macOS as a foreground console process.
- Recursive backend is available.
- Clients can call explicit `MountIndex`.
- `Search`, `ListFiles`, `GetFolderSize`, and `RefreshMount` work.
- Persistent mount config works.
- Scheduled polling refresh works through `refresh_interval_ms`.
- IPC uses Unix domain sockets.
- `watch_reliability` starts as `none` for recursive mounts. A later polling
  transport/state label can report `polling` when the scheduler is the active
  refresh mechanism.

## Non-Goals

M0 does not include:

- APFS-native indexing
- FSEvents
- system-level `launchd` service mode
- signed installer or notarization
- Spotlight integration
- File-level delta events
- Performance optimization

## Platform Boundary Audit

| Area | Classification | Current State | M0 Boundary |
| --- | --- | --- | --- |
| Named pipe IPC | must port | `sfis/src/ipc/pipe_server.cpp` owns Windows named pipe accept, read, write, and connection lifecycle. C# and C++ clients also assume named pipes. | Split command handling and binary framing from transport. Add Unix domain socket server/client transport. |
| Pipe ACL | can stub | Pipe security descriptor is enforced in the Windows named pipe creation path. | No equivalent per-file security in M0. Use filesystem permissions on the socket path and document access as host-policy controlled. |
| MFT scanner | Windows-only backend | `mft_scanner_windows.*` is NTFS-specific. | Exclude from macOS build. |
| USN watcher | Windows-only backend | `usn_watcher_windows.*` is NTFS/USN-specific. | Exclude from macOS build. |
| Volume probing | must port or bypass | `volume_probe_windows.*` probes Windows drives and NTFS capabilities. `main.cpp` and `IndexMountManager` call it directly. | M0 daemon should not auto-probe volumes on macOS. Explicit folder mounts build recursive capabilities from the requested path. |
| Win32 error formatting | can stub | `win32_error.*` is used by Windows platform code and leaked into core files. | Keep only in Windows sources. Use `std::error_code`, `errno`, or POSIX error text in macOS platform files. |
| Service mode | Windows-only mode | `main.cpp` contains Windows service install/update/run logic and global service state. | Exclude from macOS. M0 runs foreground console daemon only. |
| ProgramData path | must port | Default index/config/log paths use `%ProgramData%`. | Add platform path resolver using `~/Library/Application Support/SFIS`. Preserve env overrides. |
| Path normalization | must port | Core normalization lowercases paths and converts `/` to `\`, which is Windows-centric. | Add path policy helpers. macOS should preserve `/`, avoid unconditional lowercasing, and account for case-sensitive APFS volumes later. |
| Index snapshot path | must port | `ResolveDefaultIndexStorePath()` uses ProgramData and Win32 env APIs. | Default to `~/Library/Application Support/SFIS/index/sfis-index-v1.bin`. Support `SFIS_INDEX_PATH`. |
| Mount config path | must port | `ResolveDefaultMountConfigPath()` supports `SFIS_MOUNT_CONFIG_PATH` but otherwise uses ProgramData and Win32 env APIs. | Default to `~/Library/Application Support/SFIS/mounts.json`. Keep `SFIS_MOUNT_CONFIG_PATH`. |
| Recursive backend | must port | Implementation lives in `src/core/index_backends.cpp` but uses Win32 attributes, UTF-16 conversion, and `FILE_ATTRIBUTE_REPARSE_POINT`. | Split recursive backend into portable filesystem traversal plus platform metadata helpers. |
| Query engine | cross-platform already | `query.cpp` is independent of Win32 APIs. | Build as common core. |
| `FileIndex` | cross-platform with path caveats | In-memory index is portable, but path comparison assumes Windows separators and case folding. | Build as common core after path comparison is moved behind path policy or made platform-aware. |
| `IndexMountManager` | must port | Lives in core but includes Windows volume probing, Win32 path checks, and Windows root classification. | Keep lifecycle/scheduler logic common; move root validation, kind detection, volume probing, and backend factory selection to platform/common abstractions. |
| Scheduler | cross-platform already | Refresh scheduler uses standard C++ threading/time and mount manager APIs. | Build as common core. |
| Binary protocol | cross-platform already | `binary_protocol.*` is endian-stable and transport-agnostic. | Keep unchanged. Transport should carry the same packet bytes. |

## Build Boundary

The current build has two hard blockers for macOS:

- Top-level `CMakeLists.txt` only adds `sfis` on `WIN32`.
- `sfis/CMakeLists.txt` unconditionally includes Windows platform sources and
  links `Advapi32`.

The target layout should become:

- Common core:
  - `sfis/src/core/file_index.cpp`
  - `sfis/src/core/query.cpp`
  - `sfis/src/core/index_store.cpp` after atomic replace/path resolver is portable
  - `sfis/src/core/mount_config_store.cpp` after atomic replace/path resolver is portable
  - common parts of `index_mount.cpp`
  - portable recursive backend implementation
  - `sfis/src/ipc/binary_protocol.cpp`
- Windows-only:
  - `sfis/src/platform/*_windows.*`
  - Windows named pipe transport
  - Windows service entry/install/update code
  - NTFS MFT/USN backend
  - Windows volume probing
- macOS M0:
  - POSIX/Unix domain socket transport
  - macOS path resolver
  - POSIX metadata helper for recursive backend
  - foreground daemon entry point using recursive backend only
- Future macOS:
  - FSEvents watcher
  - APFS/platform-specific capability probing
  - system-level LaunchDaemon integration

Suggested CMake shape:

```cmake
set(SFIS_COMMON_SOURCES
  src/core/file_index.cpp
  src/core/query.cpp
  src/core/index_store.cpp
  src/core/mount_config_store.cpp
  src/ipc/binary_protocol.cpp
)

if(WIN32)
  list(APPEND SFIS_PLATFORM_SOURCES
    src/platform/mft_scanner_windows.cpp
    src/platform/usn_watcher_windows.cpp
    src/platform/volume_probe_windows.cpp
    src/platform/win32_error.cpp
    src/ipc/named_pipe_server_windows.cpp
    src/main_windows.cpp
  )
elseif(APPLE)
  list(APPEND SFIS_PLATFORM_SOURCES
    src/platform/path_locations_macos.cpp
    src/platform/file_metadata_posix.cpp
    src/ipc/unix_socket_server_posix.cpp
    src/main_posix.cpp
  )
endif()

add_executable(sfis ${SFIS_COMMON_SOURCES} ${SFIS_PLATFORM_SOURCES})
```

For M0, it is acceptable for the macOS daemon target to be recursive-only while
Windows keeps the current full backend set.

## IPC Abstraction

The binary protocol should remain transport-neutral. The current named pipe
server combines three responsibilities:

- packet framing and request dispatch
- client connection state and event subscriber queues
- Windows named pipe accept/read/write operations

M0 should split these into:

```cpp
class IpcConnection {
public:
    virtual ~IpcConnection() = default;
    virtual bool ReadExact(void* data, size_t size, std::atomic<bool>& stop) = 0;
    virtual void WriteAll(const void* data, size_t size) = 0;
    virtual void Close() = 0;
};

class IpcServerTransport {
public:
    virtual ~IpcServerTransport() = default;
    virtual void Start(
        std::function<void(std::unique_ptr<IpcConnection>)> on_connection,
        std::atomic<bool>& stop) = 0;
    virtual void Stop() = 0;
};
```

Then keep packet handling in a shared server layer:

- `ReadPacket(IpcConnection&)`
- `WritePacket(IpcConnection&)`
- `HandleHello`
- `HandleRequestPacket`
- `SfisIpcEventHub`
- subscriber queue/backpressure policy

macOS transport:

- Use `AF_UNIX`, `SOCK_STREAM`.
- Default socket path:
  `~/Library/Application Support/SFIS/run/sfis.sock`
- Dev override:
  `SFIS_SOCKET_PATH`
- `/tmp/sfis.sock` is useful for smoke tests but should not be the product
  default because it is globally shared and easier to collide.
- On startup, remove a stale socket file only after confirming no active server
  is accepting connections.
- Socket file permissions should be owner-only by default where possible.

The C# SDK boundary should follow the same transport split:

- Windows: `NamedPipeClientStream`
- macOS: `Socket(AddressFamily.Unix, SocketType.Stream, ProtocolType.Unspecified)`
- Same `SfisBinaryProtocol` packet reader/writer.

## Path And Config Locations

Default macOS locations:

- Config:
  `~/Library/Application Support/SFIS/mounts.json`
- Index:
  `~/Library/Application Support/SFIS/index/sfis-index-v1.bin`
- Socket:
  `~/Library/Application Support/SFIS/run/sfis.sock`

Environment overrides:

- `SFIS_MOUNT_CONFIG_PATH`
- `SFIS_INDEX_PATH`
- `SFIS_SOCKET_PATH`

## M11.1 User-Level Install Baseline

The first macOS package boundary is a zip plus shell scripts. It intentionally
does not include a signed `.pkg`, notarization, Homebrew formula, auto-update,
FSEvents, APFS indexing, or a system-level LaunchDaemon.

Installed layout:

```text
~/Library/Application Support/SFIS/
  bin/
    sfis
    sfisctl
  index/
    sfis-index-v1.bin
  mounts.json
  logs/
    sfis.out.log
    sfis.err.log
  run/
    sfis.sock
```

LaunchAgent:

```text
~/Library/LaunchAgents/com.sfis.daemon.plist
```

The LaunchAgent runs in the current user context with `RunAtLoad` and
`KeepAlive`, points `SFIS_INDEX_PATH` at `index/sfis-index-v1.bin`, points
`SFIS_MOUNT_CONFIG_PATH` at `mounts.json`, and points `SFIS_SOCKET_PATH` at
`run/sfis.sock`.

Package layout:

```text
SFIS-macos-arm64/
  bin/
    sfis
    sfisctl
  SFIS.Monitor/
    SFIS.Monitor
    ...
  scripts/
    install-sfis-macos.sh
    uninstall-sfis-macos.sh
    run-sfis-monitor-macos.sh
    start-sfis-macos.sh
    stop-sfis-macos.sh
    status-sfis-macos.sh
  docs/
    README.md
```

Validation:

```bash
./build-macos-zip.sh
unzip dist/SFIS-macos-arm64.zip -d /tmp/sfis-package
cd /tmp/sfis-package/SFIS-macos-arm64
./scripts/install-sfis-macos.sh --verify
./bin/sfisctl status
./scripts/status-sfis-macos.sh
./scripts/uninstall-sfis-macos.sh
```

Implementation boundary:

- Move default path resolution out of core stores and into a platform location
  helper.
- Keep stores accepting explicit paths.
- Keep atomic write semantics:
  - Windows: `MoveFileExW(..., MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)`
  - POSIX/macOS: write temp file, flush, close, `rename`, optionally fsync parent
    directory.

## Recursive Backend Validation

The first macOS backend is recursive only:

- `backend = recursive`
- `supports_watch = false`
- `watch_reliability = none`
- `refresh_interval_ms` drives polling through the existing scheduler

Validation items:

- Symlinks:
  - Do not follow directory symlinks in M0.
  - Count skipped symlink directories similarly to current reparse-point skips.
  - File symlink handling should be explicit: either index as symlink metadata or
    skip consistently. M0 should prefer skip unless metadata semantics are
    clearly defined.
- Hidden files:
  - Dotfiles are normal indexed entries.
  - Finder hidden flags are not required in M0.
  - Existing `GetFolderSize(include_hidden=false)` currently relies on Windows
    attribute bits and needs a platform metadata mapping before it is meaningful
    on macOS.
- Case sensitivity:
  - Do not hardcode lowercase path identity on macOS.
  - APFS can be case-sensitive or case-insensitive. M0 can use exact normalized
    paths and document that case-insensitive matching is not yet volume-aware.
- Path separator:
  - Preserve `/` on macOS.
  - Remove assumptions that directory paths end in `\`.
- Unicode normalization:
  - macOS paths can expose decomposed Unicode forms. M0 should store the UTF-8
    path returned by filesystem APIs without lossy conversion.
  - Add tests with composed/decomposed names before promising stable
    cross-normalization matching.
- Metadata:
  - Use `std::filesystem` plus POSIX `lstat`/`stat` where needed.
  - Synthetic ids can continue to use stable hashes of mount id plus normalized
    path for recursive mounts.

## Implementation Steps

1. Introduce platform location helpers.
   - Resolve config/index/socket paths.
   - Add `SFIS_INDEX_PATH` and `SFIS_SOCKET_PATH`.
   - Remove ProgramData decisions from core stores.

2. Split recursive backend from Windows backends.
   - Move NTFS backend factory to a Windows source file.
   - Move recursive backend to a portable source file.
   - Add a POSIX metadata helper for `is_directory`, size, timestamps, symlink
     detection, and skip reasons.

3. Split `IndexMountManager` platform hooks.
   - Root validation.
   - Mount kind classification.
   - Volume probing.
   - Backend selection.
   - M0 macOS policy: explicit folder/network-like path only, recursive backend
     only.

4. Split IPC server.
   - Shared protocol dispatch and event hub.
   - Windows named pipe transport.
   - POSIX Unix domain socket transport.

5. Add macOS daemon entry point.
   - Foreground console mode.
   - No service install/update commands.
   - No initial volume auto-probe.
   - Load snapshot and mount config.
   - Restore enabled persistent recursive mounts.
   - Start scheduler and Unix socket server.

6. Update clients.
   - C++ `sfisctl` should connect through named pipe on Windows and Unix socket
     on macOS.
   - C# SDK should select transport by OS while keeping packet encoding shared.

7. Validate with smoke tests.
   - Start daemon.
   - Mount a temp folder with recursive backend.
   - Search files.
   - List files.
   - Get folder size.
   - Refresh after create/delete/rename.
   - Persist mount config and restore after restart.
   - Verify scheduled refresh updates generation.

## M0 Acceptance Checklist

- macOS build produces `sfis` daemon and `sfisctl`.
- `sfis` starts without Windows libraries or headers.
- `sfis` does not auto-probe Windows volumes on macOS.
- Unix socket IPC completes Hello handshake.
- `MountIndex` with `backend_hint=recursive` succeeds for a readable directory.
- `Search`, `ListFiles`, `GetFolderSize`, and `RefreshMount` return results.
- Persistent recursive mounts survive restart.
- Scheduler-driven polling refresh works.
- `watch_reliability` is reported as `none` for recursive mounts.
- FSEvents, launchd, packaging, and APFS-specific optimization remain excluded.

## M4 Progress - Unix Domain Socket IPC Transport

Implemented in this milestone:

- Added POSIX `AF_UNIX` / `SOCK_STREAM` server transport behind platform guards.
- Preserved the shared binary protocol, request dispatch, event hub, and
  subscriber queue semantics.
- Kept Windows named pipe transport and `StartPipeServer` behavior unchanged.
- Added `StartUnixSocketServer` facade for POSIX daemon entry points.
- Added socket path handling through `ResolveDefaultSocketPath()` and
  `SFIS_SOCKET_PATH`.
- Added stale socket detection, stale unlink, parent directory creation, and
  owner-only socket file permissions where practical.
- Added POSIX Unix socket client support for `sfisctl`, with `--socket-path`
  override.
- Added managed SDK platform selection:
  - Windows uses `NamedPipeClientStream` and `SFIS_PIPE_NAME`.
  - macOS/Linux use `Socket(AddressFamily.Unix, SocketType.Stream,
    ProtocolType.Unspecified)` through `NetworkStream` and `SFIS_SOCKET_PATH`.

Still outside this milestone:

- Full macOS daemon build and entry point.
- launchd, packaging, FSEvents, APFS probing, and protocol changes.

## M5 Progress - Recursive-Only Daemon Build Boundary

Implemented in this milestone:

- Split the daemon entry point by platform:
  - Windows continues to build the existing service-capable `main.cpp`.
  - POSIX builds `main_posix.cpp`.
- POSIX daemon behavior is foreground console only.
- POSIX daemon uses Unix domain socket IPC through `StartUnixSocketServer`.
- POSIX daemon does not perform startup volume probing or auto-discovery.
- POSIX explicit `MountIndex` supports recursive mounts only:
  - `backend_hint=recursive` is accepted.
  - `backend_hint=auto` maps to recursive for explicit directory mounts.
  - `backend_hint=ntfs-usn` is rejected with a Windows-only error.
- `IndexMountManager` no longer requires Windows volume probing or Win32
  directory validation on non-Windows builds.
- Snapshot and mount config stores now use POSIX atomic rename behavior on
  non-Windows builds.
- CMake now builds `sfis` on non-Windows with the POSIX source set and excludes:
  - `mft_scanner_windows.cpp`
  - `usn_watcher_windows.cpp`
  - `volume_probe_windows.cpp`
  - `win32_error.cpp`
  - Windows service APIs
  - `Advapi32`
- POSIX daemon supports the self-test switches intended for the M0 substrate:
  - `--paths-self-test`
  - `--metadata-self-test`
  - `--query-self-test`
  - `--store-self-test`
  - `--recursive-self-test`

Unsupported on POSIX in M5:

- `--service`
- `--install`
- `--uninstall`
- `--update`
- `--pipe-name`
- Windows volume auto-probing and NTFS/USN backends

## M6 Progress - Client and Monitor Unix Socket Readiness

Implemented in this milestone:

- C# SDK endpoint resolution is explicit and testable:
  - Windows resolves `NamedPipe: sfis` by default and honors
    `SFIS_PIPE_NAME`.
  - macOS resolves
    `UnixSocket: ~/Library/Application Support/SFIS/run/sfis.sock` by default and
    honors `SFIS_SOCKET_PATH`.
  - Linux resolves `UnixSocket: $HOME/.local/share/SFIS/sfis.sock` by default
    and honors `SFIS_SOCKET_PATH`.
- `SfisClient.ConnectAsync()` keeps the same public API while selecting named
  pipe or Unix domain socket by OS.
- SDK connection failures now mention the selected endpoint:
  - Windows failures refer to the named pipe server.
  - macOS/Linux failures refer to the Unix socket path and `SFIS_SOCKET_PATH`.
- SDK unit tests cover endpoint defaults, environment overrides, and transport
  kind selection without requiring a live Unix socket on Windows.
- SFIS.Monitor displays endpoint kind and address in the connection banner and
  Status tab:
  - `NamedPipe: sfis` on Windows.
  - `UnixSocket: /Users/.../SFIS/run/sfis.sock` on macOS.
  - `UnixSocket: /home/.../.local/share/SFIS/sfis.sock` on Linux.
- `sfisctl` help and docs now describe Windows pipe overrides and POSIX socket
  overrides.

macOS smoke plan:

1. Start the foreground daemon:
   `export SFIS_SOCKET_PATH="$HOME/Library/Application Support/SFIS/run/sfis.sock"` then
   `./sfis --socket-path "$SFIS_SOCKET_PATH"`
2. Verify native client status:
   `./sfisctl --socket-path "$SFIS_SOCKET_PATH" status`
3. Verify C# SDK status:
   `dotnet run --project SFIS.TestApp/SFIS.TestApp.csproj -- status`
4. Launch Monitor:
   `dotnet run --project SFIS.Monitor/SFIS.Monitor.csproj`
5. In Monitor or SDK, mount a readable temp folder with `backend=recursive`.
6. Create/delete/rename files under the mount, then run refresh and verify
   `Search` and `ListFiles` reflect the refreshed index.

Still outside this milestone:

- Actual macOS compile verification.
- launchd, packaging, FSEvents, APFS probing, socket reconnect automation, and
  InsightFlow integration code.

## M7 Validation Runbook - Actual macOS Compile and Smoke

Purpose:

- Validate that the recursive-only SFIS architecture works on a real Mac with
  explicit mounts, Unix domain socket IPC, persistent config, C# SDK access, and
  Monitor access.
- Find platform abstraction leaks from the Windows-first implementation.

Prerequisites on the Mac:

```bash
xcode-select --install
cmake --version
dotnet --version
```

Required tools:

- Xcode Command Line Tools
- CMake
- .NET 8 SDK

Native build:

```bash
git clone <repo>
cd SFIS
./build-macos.sh Debug
```

Expected native outputs with the current CMake layout:

- `build-macos/bin/sfis`
- `build-macos/bin/sfisctl`

If a generator or local CMake change places runtime outputs under target
directories, use the equivalent `sfis` and `sfisctl` paths for the commands
below.

Native self-tests:

```bash
./build-macos/bin/sfis --paths-self-test
./build-macos/bin/sfis --metadata-self-test
./build-macos/bin/sfis --query-self-test
./build-macos/bin/sfis --store-self-test
./build-macos/bin/sfis --recursive-self-test
```

Failure-prone areas to inspect first:

- path separator assumptions
- case folding assumptions
- `std::filesystem` behavior differences
- POSIX atomic rename/fsync behavior
- socket path parent directory creation
- symlink skip behavior

Daemon smoke with isolated state:

```bash
export SFIS_SOCKET_PATH="$TMPDIR/sfis-dev.sock"
export SFIS_INDEX_PATH="$TMPDIR/sfis-index-v1.bin"
export SFIS_MOUNT_CONFIG_PATH="$TMPDIR/sfis-mounts.json"
./build-macos/bin/sfis
```

In another terminal:

```bash
export SFIS_SOCKET_PATH="$TMPDIR/sfis-dev.sock"
./build-macos/bin/sfisctl status
```

Expected:

- Unix socket Hello handshake succeeds.
- `status` returns.
- `process_mode` is console/foreground.
- The socket endpoint path is reported in the status `pipe_name` compatibility
  field.

Recursive mount smoke:

```bash
mkdir -p "$TMPDIR/sfis-test-root"
echo hello > "$TMPDIR/sfis-test-root/hello.txt"

./build-macos/bin/sfisctl mount "$TMPDIR/sfis-test-root" recursive Persistent
./build-macos/bin/sfisctl mounts
./build-macos/bin/sfisctl search hello 20
./build-macos/bin/sfisctl disk-files "$TMPDIR/sfis-test-root" 20
./build-macos/bin/sfisctl refresh-mount <mount_id>
```

Expected:

- mount status is `Ready`
- backend is `recursive`
- `watch_reliability` is `none`
- `generation > 0`
- search/list output includes `hello.txt`

Persistent config restart smoke:

1. Mount a persistent root with the isolated env vars above.
2. Stop the daemon.
3. Restart the daemon with the same `SFIS_SOCKET_PATH`, `SFIS_INDEX_PATH`, and
   `SFIS_MOUNT_CONFIG_PATH`.
4. Run:

```bash
./build-macos/bin/sfisctl status
./build-macos/bin/sfisctl mounts
./build-macos/bin/sfisctl mount-configs
```

Expected:

- `mount_config_loaded=true`
- `mount_config_restored >= 1`
- restored mount appears in `mounts`

C# SDK smoke:

```bash
dotnet test SFIS.Client.Tests/SFIS.Client.Tests.csproj
```

With the daemon still running and `SFIS_SOCKET_PATH` exported:

```bash
dotnet run --project SFIS.TestApp/SFIS.TestApp.csproj -- status
```

Expected:

- SDK selects Unix socket transport.
- status returns from the same daemon.

Monitor smoke:

```bash
dotnet run --project SFIS.Monitor/SFIS.Monitor.csproj
```

Expected:

- connection banner shows `UnixSocket`
- Status tab loads
- Mounts and Mount Configs tabs load
- Events subscribe works when `reactive-ipc` is advertised

First-fix priority when macOS compile or smoke fails:

1. Missing platform includes or preprocessor guards.
2. Windows-only type leakage.
3. CMake source split mistakes.
4. Filesystem path assumptions.
5. POSIX socket compile/runtime issues.
6. C# Unix socket default path issues.

M7 non-goals:

- FSEvents
- launchd
- packaging/notarization
- performance tuning
- APFS native probing
- file-level delta events

M7 completion criteria:

- macOS native build succeeds.
- Self-tests pass, or failures are documented and fixed.
- Unix socket Hello/status works.
- Recursive mount/search/list/refresh works.
- Persistent mount config restore works.
- C# SDK connects via Unix socket.
- Monitor connects via Unix socket.

## M1 Monitor Package Boundary

M1 includes SFIS Monitor in the macOS zip as an unsigned, framework-dependent
publish directory. It is not a signed `.app` and is not notarized yet.

Installed layout:

```text
~/Library/Application Support/SFIS/
  SFIS.Monitor/
    SFIS.Monitor
    ...
```

Launch from Terminal:

```bash
~/Library/Application\ Support/SFIS/SFIS.Monitor/SFIS.Monitor
```

or through the package helper:

```bash
./scripts/run-sfis-monitor-macos.sh
```

Future work can wrap the same publish output into a signed and notarized
`.app`.
